/**
 * Rauli ERP - Auth Context
 * Manejo de estado de autenticación
 */

import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import localDB from '../db/localDB';

const AuthContext = createContext(null);

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // Cargar sesión guardada
  useEffect(() => {
    const loadSession = async () => {
      try {
        const savedToken = localStorage.getItem('auth_token');
        const savedUser = localStorage.getItem('auth_user');
        
        if (savedToken && savedUser) {
          setToken(savedToken);
          setUser(JSON.parse(savedUser));
          
          // Verificar token con servidor si hay conexión
          if (navigator.onLine) {
            try {
              const response = await fetch(`${API_URL}/auth/me`, {
                headers: { 'Authorization': `Bearer ${savedToken}` }
              });
              if (response.ok) {
                const data = await response.json();
                setUser(data.user);
                localStorage.setItem('auth_user', JSON.stringify(data.user));
              } else {
                // Token inválido, limpiar
                handleLogout();
              }
            } catch (err) {
              console.log('No se pudo verificar token, usando datos locales');
            }
          }
        }
      } catch (err) {
        console.error('Error loading session:', err);
      } finally {
        setLoading(false);
      }
    };
    
    loadSession();
  }, []);

  // Monitor conexión
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      toast.success('Conexión restaurada');
    };
    const handleOffline = () => {
      setIsOnline(false);
      toast('Modo sin conexión', { icon: '📴' });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const login = useCallback(async (username, password) => {
    try {
      // Intentar login online
      if (navigator.onLine) {
        const response = await fetch(`${API_URL}/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || 'Error de autenticación');
        }

        // Guardar en localStorage y estado
        localStorage.setItem('auth_token', data.token);
        localStorage.setItem('auth_user', JSON.stringify(data.user));
        setToken(data.token);
        setUser(data.user);

        // Guardar usuario para login offline
        await localDB.saveUserForOffline(data.user, password);

        toast.success(`¡Bienvenido, ${data.user.name}!`);
        return { success: true };
      } else {
        // Login offline
        const offlineUser = await localDB.verifyOfflineLogin(username, password);
        if (offlineUser) {
          setUser(offlineUser);
          localStorage.setItem('auth_user', JSON.stringify(offlineUser));
          toast.success(`¡Bienvenido (offline), ${offlineUser.name}!`);
          return { success: true };
        } else {
          throw new Error('Credenciales no válidas para modo offline');
        }
      }
    } catch (err) {
      toast.error(err.message);
      return { success: false, error: err.message };
    }
  }, []);

  const handleLogout = useCallback(() => {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('auth_user');
    setToken(null);
    setUser(null);
  }, []);

  const logout = useCallback(async () => {
    try {
      if (navigator.onLine && token) {
        await fetch(`${API_URL}/auth/logout`, {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${token}` }
        });
      }
    } catch (err) {
      console.log('Error en logout:', err);
    } finally {
      handleLogout();
      toast.success('Sesión cerrada');
    }
  }, [token, handleLogout]);

  const changePassword = useCallback(async (currentPassword, newPassword) => {
    try {
      const response = await fetch(`${API_URL}/auth/password`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ currentPassword, newPassword })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Error al cambiar contraseña');
      }

      toast.success('Contraseña actualizada');
      return { success: true };
    } catch (err) {
      toast.error(err.message);
      return { success: false, error: err.message };
    }
  }, [token]);

  // Función helper para requests autenticados
  const authFetch = useCallback(async (url, options = {}) => {
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_URL}${url}`, {
      ...options,
      headers,
    });

    // Si token expiró, cerrar sesión
    if (response.status === 401) {
      handleLogout();
      toast.error('Sesión expirada, por favor inicie sesión');
      throw new Error('Unauthorized');
    }

    return response;
  }, [token, handleLogout]);

  const value = {
    user,
    token,
    loading,
    isOnline,
    isAuthenticated: !!user,
    login,
    logout,
    changePassword,
    authFetch,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth debe usarse dentro de AuthProvider');
  }
  return context;
}

export default AuthContext;
