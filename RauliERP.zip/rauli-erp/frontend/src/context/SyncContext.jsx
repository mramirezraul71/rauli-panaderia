/**
 * Rauli ERP - Sync Context
 * Manejo de sincronización offline/online
 */

import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import localDB from '../db/localDB';
import syncService from '../services/syncService';
import { useAuth } from './AuthContext';

const SyncContext = createContext(null);

export function SyncProvider({ children }) {
  const { authFetch, isOnline, isAuthenticated } = useAuth();
  const [syncStatus, setSyncStatus] = useState('idle'); // idle, syncing, error, success
  const [pendingCount, setPendingCount] = useState(0);
  const [lastSync, setLastSync] = useState(null);
  const [syncProgress, setSyncProgress] = useState({ current: 0, total: 0 });

  // Cargar estado de sync al iniciar
  useEffect(() => {
    const loadSyncState = async () => {
      try {
        const count = await localDB.getPendingSyncCount();
        setPendingCount(count);
        
        const lastSyncTime = localStorage.getItem('last_sync');
        if (lastSyncTime) {
          setLastSync(new Date(lastSyncTime));
        }
      } catch (err) {
        console.error('Error loading sync state:', err);
      }
    };
    
    loadSyncState();
  }, []);

  // Auto-sync cuando vuelve la conexión
  useEffect(() => {
    if (isOnline && isAuthenticated && pendingCount > 0) {
      // Pequeño delay para asegurar estabilidad de conexión
      const timeout = setTimeout(() => {
        syncAll();
      }, 2000);
      
      return () => clearTimeout(timeout);
    }
  }, [isOnline, isAuthenticated]);

  // Sincronizar todos los datos pendientes
  const syncAll = useCallback(async () => {
    if (!isOnline) {
      toast.error('Sin conexión a internet');
      return { success: false };
    }

    if (syncStatus === 'syncing') {
      return { success: false, message: 'Sincronización en progreso' };
    }

    setSyncStatus('syncing');
    
    try {
      const pendingItems = await localDB.getPendingSync();
      const total = pendingItems.length;
      
      if (total === 0) {
        setSyncStatus('success');
        toast.success('Todo está sincronizado');
        return { success: true };
      }

      setSyncProgress({ current: 0, total });
      let successCount = 0;
      let errorCount = 0;

      for (let i = 0; i < pendingItems.length; i++) {
        const item = pendingItems[i];
        setSyncProgress({ current: i + 1, total });

        try {
          const result = await syncService.syncItem(item, authFetch);
          
          if (result.success) {
            await localDB.markSynced(item.id);
            successCount++;
          } else {
            await localDB.markSyncError(item.id, result.error);
            errorCount++;
          }
        } catch (err) {
          await localDB.markSyncError(item.id, err.message);
          errorCount++;
        }
      }

      // Actualizar contadores
      const newPendingCount = await localDB.getPendingSyncCount();
      setPendingCount(newPendingCount);

      // Guardar tiempo de última sincronización
      const now = new Date();
      localStorage.setItem('last_sync', now.toISOString());
      setLastSync(now);

      if (errorCount === 0) {
        setSyncStatus('success');
        toast.success(`${successCount} elementos sincronizados`);
      } else {
        setSyncStatus('error');
        toast.error(`${errorCount} errores, ${successCount} sincronizados`);
      }

      return { success: errorCount === 0, successCount, errorCount };
    } catch (err) {
      console.error('Sync error:', err);
      setSyncStatus('error');
      toast.error('Error de sincronización');
      return { success: false, error: err.message };
    }
  }, [isOnline, syncStatus, authFetch]);

  // Agregar item a cola de sync
  const addToSyncQueue = useCallback(async (type, action, data) => {
    try {
      await localDB.addToSyncQueue({
        type,      // 'sale', 'product', 'inventory', etc
        action,    // 'create', 'update', 'delete'
        data,
        timestamp: new Date().toISOString(),
      });

      const count = await localDB.getPendingSyncCount();
      setPendingCount(count);

      // Si hay conexión, sincronizar inmediatamente
      if (isOnline && isAuthenticated) {
        setTimeout(() => syncAll(), 500);
      }
    } catch (err) {
      console.error('Error adding to sync queue:', err);
    }
  }, [isOnline, isAuthenticated, syncAll]);

  // Descargar datos del servidor para uso offline
  const downloadOfflineData = useCallback(async () => {
    if (!isOnline) {
      toast.error('Se requiere conexión para descargar datos');
      return { success: false };
    }

    setSyncStatus('syncing');
    
    try {
      toast.loading('Descargando datos...', { id: 'download' });

      // Descargar productos
      const productsRes = await authFetch('/products');
      if (productsRes.ok) {
        const { products } = await productsRes.json();
        await localDB.bulkSaveProducts(products);
      }

      // Descargar categorías
      const categoriesRes = await authFetch('/products/categories');
      if (categoriesRes.ok) {
        const { categories } = await categoriesRes.json();
        await localDB.bulkSaveCategories(categories);
      }

      // Descargar empleados (si tiene permiso)
      try {
        const employeesRes = await authFetch('/employees');
        if (employeesRes.ok) {
          const { employees } = await employeesRes.json();
          await localDB.bulkSaveEmployees(employees);
        }
      } catch (err) {
        // Ignorar si no tiene permiso
      }

      toast.success('Datos descargados para uso offline', { id: 'download' });
      setSyncStatus('success');
      return { success: true };
    } catch (err) {
      console.error('Download error:', err);
      toast.error('Error al descargar datos', { id: 'download' });
      setSyncStatus('error');
      return { success: false, error: err.message };
    }
  }, [isOnline, authFetch]);

  // Limpiar datos locales
  const clearLocalData = useCallback(async () => {
    try {
      await localDB.clearAll();
      setPendingCount(0);
      setLastSync(null);
      localStorage.removeItem('last_sync');
      toast.success('Datos locales eliminados');
    } catch (err) {
      toast.error('Error al limpiar datos');
    }
  }, []);

  const value = {
    syncStatus,
    pendingCount,
    lastSync,
    syncProgress,
    syncAll,
    addToSyncQueue,
    downloadOfflineData,
    clearLocalData,
  };

  return (
    <SyncContext.Provider value={value}>
      {children}
    </SyncContext.Provider>
  );
}

export function useSync() {
  const context = useContext(SyncContext);
  if (!context) {
    throw new Error('useSync debe usarse dentro de SyncProvider');
  }
  return context;
}

export default SyncContext;
