/**
 * Rauli ERP - Servicio de Sincronización
 * Maneja la sincronización entre IndexedDB y el servidor
 */

import { 
  ProductsDB, 
  CategoriesDB, 
  SalesDB, 
  SyncQueueDB, 
  SettingsDB,
  EmployeesDB,
  CacheDB 
} from '../db/localDB';
import api from './api';

// Estado de sincronización
let isSyncing = false;
let syncInterval = null;
let listeners = [];

// ==================== GESTIÓN DE ESTADO ====================

export const SyncStatus = {
  IDLE: 'idle',
  SYNCING: 'syncing',
  SUCCESS: 'success',
  ERROR: 'error',
  OFFLINE: 'offline'
};

let currentStatus = SyncStatus.IDLE;
let lastSyncTime = null;
let pendingCount = 0;

export function getStatus() {
  return {
    status: currentStatus,
    lastSync: lastSyncTime,
    pending: pendingCount,
    isOnline: navigator.onLine
  };
}

export function subscribe(callback) {
  listeners.push(callback);
  return () => {
    listeners = listeners.filter(l => l !== callback);
  };
}

function notifyListeners() {
  const status = getStatus();
  listeners.forEach(callback => callback(status));
}

function setStatus(status) {
  currentStatus = status;
  notifyListeners();
}

// ==================== SINCRONIZACIÓN DE DATOS ====================

/**
 * Sincronización completa (pull + push)
 */
export async function fullSync() {
  if (isSyncing) {
    console.log('⏳ Sincronización ya en progreso');
    return false;
  }
  
  if (!navigator.onLine) {
    setStatus(SyncStatus.OFFLINE);
    return false;
  }
  
  isSyncing = true;
  setStatus(SyncStatus.SYNCING);
  
  try {
    // 1. Push: Enviar datos locales pendientes
    await pushLocalChanges();
    
    // 2. Pull: Obtener datos del servidor
    await pullServerData();
    
    // Actualizar estado
    lastSyncTime = new Date();
    pendingCount = await SyncQueueDB.count();
    setStatus(SyncStatus.SUCCESS);
    
    console.log('✓ Sincronización completada');
    return true;
  } catch (error) {
    console.error('✗ Error en sincronización:', error);
    setStatus(SyncStatus.ERROR);
    return false;
  } finally {
    isSyncing = false;
  }
}

/**
 * Push: Enviar cambios locales al servidor
 */
async function pushLocalChanges() {
  const pending = await SyncQueueDB.getPending();
  
  if (pending.length === 0) {
    console.log('📤 Sin cambios pendientes');
    return;
  }
  
  console.log(`📤 Enviando ${pending.length} cambios...`);
  
  // Agrupar por tipo de entidad
  const salesOperations = pending.filter(p => p.entity_type === 'sale');
  const otherOperations = pending.filter(p => p.entity_type !== 'sale');
  
  // Sincronizar ventas
  if (salesOperations.length > 0) {
    try {
      const salesData = salesOperations.map(op => {
        const data = JSON.parse(op.data);
        return {
          ...data.sale,
          items: data.items
        };
      });
      
      const response = await api.post('/sync/sales', {
        sales: salesData,
        device_id: getDeviceId()
      });
      
      if (response.data.success) {
        // Marcar como sincronizadas
        const syncedIds = salesOperations.map(op => op.id);
        await SyncQueueDB.markSynced(syncedIds);
        
        // Actualizar IDs de servidor
        for (const result of response.data.synced) {
          await SalesDB.markSynced(result.local_id, result.server_id);
        }
        
        console.log(`✓ ${response.data.synced.length} ventas sincronizadas`);
      }
    } catch (error) {
      console.error('Error sincronizando ventas:', error);
      throw error;
    }
  }
  
  // Sincronizar otras operaciones
  if (otherOperations.length > 0) {
    try {
      const response = await api.post('/sync/push', {
        operations: otherOperations.map(op => ({
          ...op,
          data: JSON.parse(op.data)
        })),
        device_id: getDeviceId()
      });
      
      if (response.data.success) {
        const syncedIds = otherOperations.map(op => op.id);
        await SyncQueueDB.markSynced(syncedIds);
      }
    } catch (error) {
      console.error('Error sincronizando operaciones:', error);
    }
  }
}

/**
 * Pull: Obtener datos del servidor
 */
async function pullServerData() {
  console.log('📥 Obteniendo datos del servidor...');
  
  const lastSync = await SettingsDB.get('last_sync_timestamp');
  
  try {
    const response = await api.post('/sync/pull', {
      device_id: getDeviceId(),
      last_sync_timestamp: lastSync || null,
      tables: ['products', 'categories', 'employees', 'settings', 'cash_registers']
    });
    
    if (response.data.success) {
      const { data, server_timestamp } = response.data;
      
      // Actualizar productos
      if (data.products && data.products.length > 0) {
        await ProductsDB.upsertMany(data.products);
        console.log(`✓ ${data.products.length} productos actualizados`);
      }
      
      // Actualizar categorías
      if (data.categories && data.categories.length > 0) {
        await CategoriesDB.upsertMany(data.categories);
        console.log(`✓ ${data.categories.length} categorías actualizadas`);
      }
      
      // Actualizar empleados
      if (data.employees && data.employees.length > 0) {
        await EmployeesDB.upsertMany(data.employees);
        console.log(`✓ ${data.employees.length} empleados actualizados`);
      }
      
      // Actualizar configuración
      if (data.settings && data.settings.length > 0) {
        await SettingsDB.setMany(data.settings);
        console.log(`✓ ${data.settings.length} configuraciones actualizadas`);
      }
      
      // Guardar timestamp de última sincronización
      await SettingsDB.set('last_sync_timestamp', server_timestamp);
    }
  } catch (error) {
    console.error('Error obteniendo datos:', error);
    throw error;
  }
}

// ==================== SINCRONIZACIÓN EN SEGUNDO PLANO ====================

/**
 * Iniciar sincronización automática
 */
export function startAutoSync(intervalMs = 30000) {
  if (syncInterval) {
    clearInterval(syncInterval);
  }
  
  console.log(`🔄 Auto-sync cada ${intervalMs / 1000} segundos`);
  
  // Sincronizar inmediatamente
  fullSync();
  
  // Configurar intervalo
  syncInterval = setInterval(() => {
    if (navigator.onLine && !isSyncing) {
      fullSync();
    }
  }, intervalMs);
  
  // Escuchar cambios de conectividad
  window.addEventListener('online', handleOnline);
  window.addEventListener('offline', handleOffline);
}

/**
 * Detener sincronización automática
 */
export function stopAutoSync() {
  if (syncInterval) {
    clearInterval(syncInterval);
    syncInterval = null;
  }
  
  window.removeEventListener('online', handleOnline);
  window.removeEventListener('offline', handleOffline);
}

function handleOnline() {
  console.log('🌐 Conexión restaurada');
  setStatus(SyncStatus.IDLE);
  fullSync(); // Sincronizar inmediatamente al reconectar
}

function handleOffline() {
  console.log('📴 Sin conexión - modo offline');
  setStatus(SyncStatus.OFFLINE);
}

// ==================== SINCRONIZACIÓN ESPECÍFICA ====================

/**
 * Sincronizar solo productos (para refresh rápido)
 */
export async function syncProducts() {
  if (!navigator.onLine) return false;
  
  try {
    const response = await api.get('/products');
    if (response.data.success) {
      await ProductsDB.upsertMany(response.data.products);
      return true;
    }
  } catch (error) {
    console.error('Error sincronizando productos:', error);
  }
  return false;
}

/**
 * Sincronizar solo empleados
 */
export async function syncEmployees() {
  if (!navigator.onLine) return false;
  
  try {
    const response = await api.get('/employees');
    if (response.data.success) {
      await EmployeesDB.upsertMany(response.data.employees);
      return true;
    }
  } catch (error) {
    console.error('Error sincronizando empleados:', error);
  }
  return false;
}

// ==================== UTILIDADES ====================

/**
 * Obtener ID único del dispositivo
 */
function getDeviceId() {
  let deviceId = localStorage.getItem('device_id');
  if (!deviceId) {
    deviceId = `device_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem('device_id', deviceId);
  }
  return deviceId;
}

/**
 * Limpiar cola de sincronización (operaciones ya sincronizadas)
 */
export async function cleanSyncQueue() {
  await SyncQueueDB.clear();
  pendingCount = 0;
  notifyListeners();
}

/**
 * Obtener estadísticas de sincronización
 */
export async function getSyncStats() {
  const pending = await SyncQueueDB.count();
  const lastSync = await SettingsDB.get('last_sync_timestamp');
  
  return {
    pendingOperations: pending,
    lastSyncTime: lastSync,
    isOnline: navigator.onLine,
    isSyncing
  };
}

/**
 * Forzar sincronización completa (reset)
 */
export async function forceFullSync() {
  // Limpiar caché
  await CacheDB.clear();
  await SettingsDB.set('last_sync_timestamp', null);
  
  // Sincronizar
  return await fullSync();
}

// ==================== INTEGRACIÓN CON SERVICE WORKER ====================

/**
 * Registrar Background Sync para sincronización cuando vuelva la conexión
 */
export async function registerBackgroundSync(tag = 'sync-sales') {
  if ('serviceWorker' in navigator && 'SyncManager' in window) {
    try {
      const registration = await navigator.serviceWorker.ready;
      await registration.sync.register(tag);
      console.log(`✓ Background sync registrado: ${tag}`);
      return true;
    } catch (error) {
      console.error('Error registrando background sync:', error);
      return false;
    }
  }
  return false;
}

/**
 * Escuchar mensajes del Service Worker
 */
export function listenToServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('message', async (event) => {
      const { type, data } = event.data || {};
      
      switch (type) {
        case 'SYNC_AVAILABLE':
          console.log('📡 Service Worker indica que hay conexión disponible');
          if (!isSyncing) {
            fullSync();
          }
          break;
          
        case 'SYNC_COMPLETE':
          console.log('✓ Sincronización en segundo plano completada');
          setStatus(SyncStatus.SUCCESS);
          notifyListeners();
          break;
          
        case 'SYNC_ERROR':
          console.error('✗ Error en sincronización en segundo plano:', data?.error);
          setStatus(SyncStatus.ERROR);
          notifyListeners();
          break;
          
        default:
          break;
      }
    });
    
    console.log('👂 Escuchando mensajes del Service Worker');
  }
}

/**
 * Sincronizar un item específico (usado por SyncContext)
 */
export async function syncItem(item, authFetch) {
  if (!navigator.onLine) {
    return { success: false, error: 'Sin conexión' };
  }
  
  const { type, action, data } = item;
  
  try {
    let endpoint = '';
    let method = 'POST';
    let body = data;
    
    // Determinar endpoint y método según tipo y acción
    switch (type) {
      case 'sale':
        endpoint = '/sales';
        method = action === 'create' ? 'POST' : 'PUT';
        break;
        
      case 'product':
        endpoint = action === 'create' ? '/products' : `/products/${data.id}`;
        method = action === 'delete' ? 'DELETE' : (action === 'create' ? 'POST' : 'PUT');
        break;
        
      case 'inventory':
        endpoint = action === 'adjustment' ? '/inventory/adjustment' : '/inventory/lots';
        break;
        
      case 'employee':
        endpoint = action === 'create' ? '/employees' : `/employees/${data.id}`;
        method = action === 'delete' ? 'DELETE' : (action === 'create' ? 'POST' : 'PUT');
        break;
        
      case 'accounting':
        endpoint = '/accounting/entries';
        break;
        
      default:
        return { success: false, error: `Tipo desconocido: ${type}` };
    }
    
    // Realizar petición
    let response;
    if (authFetch) {
      response = await authFetch(endpoint, {
        method,
        body: method !== 'DELETE' ? JSON.stringify(body) : undefined
      });
    } else {
      response = await api[method.toLowerCase()](endpoint, body);
    }
    
    // Verificar respuesta
    const responseData = authFetch ? await response.json() : response.data;
    
    if (response.ok || responseData.success) {
      return { success: true, data: responseData };
    } else {
      return { 
        success: false, 
        error: responseData.error || 'Error desconocido',
        retryable: response.status >= 500 // Errores de servidor son reintentables
      };
    }
  } catch (error) {
    console.error(`Error sincronizando ${type}:`, error);
    return { 
      success: false, 
      error: error.message,
      retryable: true // Errores de red son reintentables
    };
  }
}

/**
 * Enviar notificación al Service Worker
 */
export async function notifyServiceWorker(message) {
  if ('serviceWorker' in navigator) {
    const registration = await navigator.serviceWorker.ready;
    if (registration.active) {
      registration.active.postMessage(message);
    }
  }
}

/**
 * Verificar si hay actualizaciones del Service Worker
 */
export async function checkForUpdates() {
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.ready;
      await registration.update();
      console.log('✓ Service Worker actualizado');
      return true;
    } catch (error) {
      console.error('Error actualizando SW:', error);
      return false;
    }
  }
  return false;
}

// Iniciar escucha de SW al cargar el módulo
listenToServiceWorker();

export default {
  fullSync,
  startAutoSync,
  stopAutoSync,
  syncProducts,
  syncEmployees,
  getStatus,
  subscribe,
  cleanSyncQueue,
  getSyncStats,
  forceFullSync,
  syncItem,
  registerBackgroundSync,
  listenToServiceWorker,
  notifyServiceWorker,
  checkForUpdates,
  SyncStatus
};
