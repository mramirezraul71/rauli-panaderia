/**
 * Rauli ERP - Base de Datos Local (IndexedDB)
 * Usando Dexie.js para offline-first
 */

import Dexie from 'dexie';

// Crear instancia de base de datos
export const db = new Dexie('RauliERP');

// Definir esquema (versión 1)
db.version(1).stores({
  // Productos y categorías
  products: 'id, barcode, name, category_id, active, updated_at',
  categories: 'id, name, active',
  
  // Ventas
  sales: 'id, local_id, sale_number, status, synced, created_at',
  saleItems: '++id, sale_id, product_id',
  
  // Sesiones de caja
  cashSessions: 'id, local_id, status, synced, opened_at',
  
  // Inventario
  inventoryMovements: '++id, local_id, product_id, synced, created_at',
  
  // Empleados
  employees: 'id, code, name, active',
  
  // Configuración
  settings: 'key',
  
  // Cola de sincronización
  syncQueue: '++id, entity_type, operation, synced, created_at',
  
  // Caché de datos del servidor
  serverCache: 'key, expires_at',
  
  // Sesión de usuario
  authSession: 'key'
});

// ==================== HELPERS DE PRODUCTOS ====================

export const ProductsDB = {
  async getAll() {
    return await db.products.where('active').equals(1).toArray();
  },
  
  async getByCategory(categoryId) {
    return await db.products
      .where({ category_id: categoryId, active: 1 })
      .toArray();
  },
  
  async getByBarcode(barcode) {
    return await db.products.where('barcode').equals(barcode).first();
  },
  
  async search(query) {
    const lowerQuery = query.toLowerCase();
    return await db.products
      .filter(p => 
        p.active === 1 && 
        (p.name.toLowerCase().includes(lowerQuery) ||
         (p.barcode && p.barcode.includes(query)))
      )
      .toArray();
  },
  
  async upsertMany(products) {
    return await db.products.bulkPut(products);
  },
  
  async updateStock(productId, quantity) {
    return await db.products
      .where('id')
      .equals(productId)
      .modify(p => {
        p.stock = Math.max(0, p.stock - quantity);
        p.updated_at = new Date().toISOString();
      });
  }
};

// ==================== HELPERS DE CATEGORÍAS ====================

export const CategoriesDB = {
  async getAll() {
    return await db.categories.where('active').equals(1).toArray();
  },
  
  async upsertMany(categories) {
    return await db.categories.bulkPut(categories);
  }
};

// ==================== HELPERS DE VENTAS ====================

export const SalesDB = {
  async create(sale, items) {
    const localId = `local_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const saleData = {
      ...sale,
      id: localId,
      local_id: localId,
      synced: 0,
      created_at: new Date().toISOString()
    };
    
    // Guardar en transacción
    await db.transaction('rw', [db.sales, db.saleItems, db.products, db.syncQueue], async () => {
      // Guardar venta
      await db.sales.add(saleData);
      
      // Guardar items
      const itemsData = items.map(item => ({
        ...item,
        sale_id: localId
      }));
      await db.saleItems.bulkAdd(itemsData);
      
      // Actualizar stock de productos
      for (const item of items) {
        await ProductsDB.updateStock(item.product_id, item.quantity);
      }
      
      // Agregar a cola de sincronización
      await db.syncQueue.add({
        entity_type: 'sale',
        entity_id: localId,
        operation: 'create',
        data: JSON.stringify({ sale: saleData, items: itemsData }),
        synced: 0,
        created_at: new Date().toISOString()
      });
    });
    
    return localId;
  },
  
  async getById(id) {
    const sale = await db.sales.get(id);
    if (sale) {
      sale.items = await db.saleItems.where('sale_id').equals(id).toArray();
    }
    return sale;
  },
  
  async getToday() {
    const today = new Date().toISOString().split('T')[0];
    return await db.sales
      .filter(s => s.created_at.startsWith(today) && s.status === 'completed')
      .toArray();
  },
  
  async getPending() {
    return await db.sales.where('synced').equals(0).toArray();
  },
  
  async markSynced(localId, serverId) {
    return await db.sales
      .where('local_id')
      .equals(localId)
      .modify({ synced: 1, server_id: serverId });
  }
};

// ==================== HELPERS DE SESIÓN DE CAJA ====================

export const CashSessionDB = {
  async getCurrent() {
    return await db.cashSessions
      .where('status')
      .equals('open')
      .first();
  },
  
  async open(sessionData) {
    const localId = `session_${Date.now()}`;
    const data = {
      ...sessionData,
      id: localId,
      local_id: localId,
      status: 'open',
      synced: 0,
      opened_at: new Date().toISOString()
    };
    
    await db.cashSessions.add(data);
    
    await db.syncQueue.add({
      entity_type: 'cash_session',
      entity_id: localId,
      operation: 'open',
      data: JSON.stringify(data),
      synced: 0,
      created_at: new Date().toISOString()
    });
    
    return localId;
  },
  
  async close(sessionId, closeData) {
    await db.cashSessions
      .where('id')
      .equals(sessionId)
      .modify({
        status: 'closed',
        ...closeData,
        closed_at: new Date().toISOString()
      });
    
    await db.syncQueue.add({
      entity_type: 'cash_session',
      entity_id: sessionId,
      operation: 'close',
      data: JSON.stringify(closeData),
      synced: 0,
      created_at: new Date().toISOString()
    });
  }
};

// ==================== HELPERS DE COLA DE SINCRONIZACIÓN ====================

export const SyncQueueDB = {
  async getPending() {
    return await db.syncQueue.where('synced').equals(0).toArray();
  },
  
  async markSynced(ids) {
    return await db.syncQueue
      .where('id')
      .anyOf(ids)
      .modify({ synced: 1, synced_at: new Date().toISOString() });
  },
  
  async clear() {
    return await db.syncQueue.where('synced').equals(1).delete();
  },
  
  async count() {
    return await db.syncQueue.where('synced').equals(0).count();
  }
};

// ==================== HELPERS DE CONFIGURACIÓN ====================

export const SettingsDB = {
  async get(key) {
    const setting = await db.settings.get(key);
    return setting?.value;
  },
  
  async set(key, value) {
    return await db.settings.put({ key, value, updated_at: new Date().toISOString() });
  },
  
  async getAll() {
    return await db.settings.toArray();
  },
  
  async setMany(settings) {
    const data = settings.map(s => ({
      key: s.key,
      value: s.value,
      updated_at: new Date().toISOString()
    }));
    return await db.settings.bulkPut(data);
  }
};

// ==================== HELPERS DE EMPLEADOS ====================

export const EmployeesDB = {
  async getAll() {
    return await db.employees.where('active').equals(1).toArray();
  },
  
  async getById(id) {
    return await db.employees.get(id);
  },
  
  async upsertMany(employees) {
    return await db.employees.bulkPut(employees);
  }
};

// ==================== HELPERS DE AUTENTICACIÓN ====================

export const AuthDB = {
  async saveSession(user, token) {
    await db.authSession.put({
      key: 'current',
      user,
      token,
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 horas
    });
  },
  
  async getSession() {
    const session = await db.authSession.get('current');
    if (session && new Date(session.expires_at) > new Date()) {
      return session;
    }
    return null;
  },
  
  async clearSession() {
    await db.authSession.delete('current');
  }
};

// ==================== CACHÉ DEL SERVIDOR ====================

export const CacheDB = {
  async get(key) {
    const cached = await db.serverCache.get(key);
    if (cached && new Date(cached.expires_at) > new Date()) {
      return cached.data;
    }
    return null;
  },
  
  async set(key, data, ttlMinutes = 60) {
    const expires_at = new Date(Date.now() + ttlMinutes * 60 * 1000).toISOString();
    await db.serverCache.put({ key, data, expires_at });
  },
  
  async clear() {
    await db.serverCache.clear();
  }
};

// ==================== INICIALIZACIÓN ====================

export async function initializeLocalDB() {
  try {
    // Verificar si hay datos de ejemplo
    const productCount = await db.products.count();
    
    if (productCount === 0) {
      console.log('📦 Base de datos local vacía - esperando sincronización inicial');
    } else {
      console.log(`✓ Base de datos local lista (${productCount} productos)`);
    }
    
    return true;
  } catch (error) {
    console.error('Error inicializando DB local:', error);
    return false;
  }
}

// ==================== API UNIFICADA ====================
// Wrapper para uso fácil en componentes

const localDB = {
  // Productos
  getProducts: ProductsDB.getAll,
  getProductsByCategory: ProductsDB.getByCategory,
  getProductByBarcode: ProductsDB.getByBarcode,
  searchProducts: ProductsDB.search,
  bulkSaveProducts: ProductsDB.upsertMany,
  updateProductStock: ProductsDB.updateStock,
  
  // Categorías
  getCategories: CategoriesDB.getAll,
  bulkSaveCategories: CategoriesDB.upsertMany,
  
  // Empleados
  getEmployees: EmployeesDB.getAll,
  bulkSaveEmployees: EmployeesDB.upsertMany,
  
  // Ventas
  saveSale: async (saleData) => {
    const localId = `local_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    await db.sales.add({
      ...saleData,
      id: localId,
      local_id: saleData.local_id || localId,
      synced: 0,
      created_at: new Date().toISOString()
    });
    return localId;
  },
  getSale: SalesDB.getById,
  getTodaySales: SalesDB.getToday,
  getPendingSales: SalesDB.getPending,
  
  // Sesión de caja
  getCurrentCashSession: CashSessionDB.getCurrent,
  openCashSession: CashSessionDB.open,
  closeCashSession: CashSessionDB.close,
  
  // Cola de sincronización
  addToSyncQueue: async (item) => {
    await db.syncQueue.add({
      ...item,
      synced: 0,
      created_at: new Date().toISOString()
    });
  },
  getPendingSync: SyncQueueDB.getPending,
  getPendingSyncCount: SyncQueueDB.count,
  markSynced: async (id) => {
    await db.syncQueue.where('id').equals(id).modify({ synced: 1, synced_at: new Date().toISOString() });
  },
  markSyncError: async (id, error) => {
    await db.syncQueue.where('id').equals(id).modify({ error, error_at: new Date().toISOString() });
  },
  clearSyncedQueue: SyncQueueDB.clear,
  
  // Configuración
  getSetting: SettingsDB.get,
  setSetting: SettingsDB.set,
  getSettings: SettingsDB.getAll,
  
  // Autenticación offline
  saveUserForOffline: async (user, password) => {
    // Guardar hash simple para verificación offline
    const hash = btoa(`${user.username}:${password}`);
    await db.authSession.put({
      key: `offline_${user.username}`,
      user,
      hash,
      created_at: new Date().toISOString()
    });
  },
  verifyOfflineLogin: async (username, password) => {
    const hash = btoa(`${username}:${password}`);
    const session = await db.authSession.get(`offline_${username}`);
    if (session && session.hash === hash) {
      return session.user;
    }
    return null;
  },
  
  // Caché
  getCache: CacheDB.get,
  setCache: CacheDB.set,
  clearCache: CacheDB.clear,
  
  // Utilidades
  clearAll: async () => {
    await db.transaction('rw', db.tables, async () => {
      for (const table of db.tables) {
        await table.clear();
      }
    });
  },
  
  // Inicialización
  initialize: initializeLocalDB,
};

export default localDB;
