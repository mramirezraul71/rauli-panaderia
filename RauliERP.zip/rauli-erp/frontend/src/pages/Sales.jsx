/**
 * Rauli ERP - Sales Page
 * Historial de ventas, sesiones de caja y análisis
 */

import { useState, useEffect } from 'react';
import {
  HiOutlineShoppingCart,
  HiOutlineCash,
  HiOutlineChartBar,
  HiOutlineCalendar,
  HiOutlineCreditCard,
  HiOutlineReceiptRefund,
  HiOutlineUser,
  HiOutlineClock,
  HiOutlineEye,
  HiOutlineX,
  HiOutlineFilter,
  HiOutlineTrendingUp,
  HiOutlineTrendingDown,
  HiOutlineRefresh,
  HiOutlineDocumentDownload,
  HiOutlineCheckCircle,
  HiOutlineExclamationCircle,
  HiOutlineBan
} from 'react-icons/hi';
import { sales, employees, reports } from '../services/api';

// ==================== COMPONENTES AUXILIARES ====================

const StatCard = ({ icon: Icon, title, value, subtitle, color = 'purple', trend }) => (
  <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5">
    <div className="flex items-center justify-between">
      <div className={`p-3 rounded-lg bg-${color}-500/10`}>
        <Icon className={`w-6 h-6 text-${color}-400`} />
      </div>
      {trend !== undefined && (
        <div className={`flex items-center text-sm ${trend >= 0 ? 'text-green-400' : 'text-red-400'}`}>
          {trend >= 0 ? <HiOutlineTrendingUp className="w-4 h-4 mr-1" /> : <HiOutlineTrendingDown className="w-4 h-4 mr-1" />}
          {Math.abs(trend).toFixed(1)}%
        </div>
      )}
    </div>
    <p className="mt-4 text-2xl font-bold text-white">{value}</p>
    <p className="text-sm text-slate-400">{title}</p>
    {subtitle && <p className="text-xs text-slate-500 mt-1">{subtitle}</p>}
  </div>
);

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN'
  }).format(amount || 0);
};

const formatDate = (dateString) => {
  if (!dateString) return '-';
  return new Date(dateString).toLocaleDateString('es-MX', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};

const formatDateTime = (dateString) => {
  if (!dateString) return '-';
  return new Date(dateString).toLocaleString('es-MX', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

const formatTime = (dateString) => {
  if (!dateString) return '-';
  return new Date(dateString).toLocaleTimeString('es-MX', {
    hour: '2-digit',
    minute: '2-digit'
  });
};

const PaymentMethodBadge = ({ method }) => {
  const styles = {
    efectivo: 'bg-green-500/10 text-green-400 border-green-500/30',
    tarjeta: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    transferencia: 'bg-purple-500/10 text-purple-400 border-purple-500/30'
  };
  const labels = {
    efectivo: 'Efectivo',
    tarjeta: 'Tarjeta',
    transferencia: 'Transferencia'
  };
  return (
    <span className={`px-2 py-1 rounded-lg border text-xs font-medium ${styles[method] || styles.efectivo}`}>
      {labels[method] || method}
    </span>
  );
};

const StatusBadge = ({ status }) => {
  const styles = {
    completed: 'bg-green-500/10 text-green-400 border-green-500/30',
    cancelled: 'bg-red-500/10 text-red-400 border-red-500/30',
    pending: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30',
    open: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    closed: 'bg-slate-500/10 text-slate-400 border-slate-500/30'
  };
  const labels = {
    completed: 'Completada',
    cancelled: 'Cancelada',
    pending: 'Pendiente',
    open: 'Abierta',
    closed: 'Cerrada'
  };
  return (
    <span className={`px-2 py-1 rounded-lg border text-xs font-medium ${styles[status] || styles.pending}`}>
      {labels[status] || status}
    </span>
  );
};

// ==================== MODALES ====================

// Modal de detalle de venta
const SaleDetailModal = ({ sale, onClose }) => {
  if (!sale) return null;
  
  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <div>
            <h2 className="text-xl font-bold text-white">Detalle de Venta</h2>
            <p className="text-sm text-slate-400">#{sale.id?.slice(0, 8)}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <HiOutlineX className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-6 space-y-6">
          {/* Info general */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-slate-400">Fecha</p>
              <p className="text-white">{formatDateTime(sale.created_at)}</p>
            </div>
            <div>
              <p className="text-sm text-slate-400">Estado</p>
              <StatusBadge status={sale.status} />
            </div>
            <div>
              <p className="text-sm text-slate-400">Vendedor</p>
              <p className="text-white">{sale.employee_name || 'No asignado'}</p>
            </div>
            <div>
              <p className="text-sm text-slate-400">Método de Pago</p>
              <PaymentMethodBadge method={sale.payment_method} />
            </div>
            {sale.customer_name && (
              <div className="col-span-2">
                <p className="text-sm text-slate-400">Cliente</p>
                <p className="text-white">{sale.customer_name}</p>
              </div>
            )}
          </div>
          
          {/* Productos */}
          <div>
            <h3 className="font-medium text-white mb-3">Productos</h3>
            <div className="bg-slate-900/50 rounded-lg overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left p-3 text-sm text-slate-400">Producto</th>
                    <th className="text-center p-3 text-sm text-slate-400">Cant.</th>
                    <th className="text-right p-3 text-sm text-slate-400">Precio</th>
                    <th className="text-right p-3 text-sm text-slate-400">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {sale.items?.map((item, idx) => (
                    <tr key={idx} className="border-b border-slate-700/50">
                      <td className="p-3 text-white">{item.product_name}</td>
                      <td className="p-3 text-center text-slate-300">{item.quantity}</td>
                      <td className="p-3 text-right text-slate-300">{formatCurrency(item.unit_price)}</td>
                      <td className="p-3 text-right text-white font-medium">{formatCurrency(item.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          
          {/* Totales */}
          <div className="bg-slate-900/50 rounded-lg p-4 space-y-2">
            <div className="flex justify-between text-slate-300">
              <span>Subtotal</span>
              <span>{formatCurrency(sale.subtotal)}</span>
            </div>
            {sale.discount > 0 && (
              <div className="flex justify-between text-red-400">
                <span>Descuento</span>
                <span>-{formatCurrency(sale.discount)}</span>
              </div>
            )}
            {sale.tax > 0 && (
              <div className="flex justify-between text-slate-300">
                <span>IVA</span>
                <span>{formatCurrency(sale.tax)}</span>
              </div>
            )}
            <div className="flex justify-between text-white font-bold text-lg border-t border-slate-700 pt-2">
              <span>Total</span>
              <span>{formatCurrency(sale.total)}</span>
            </div>
            {sale.payment_method === 'efectivo' && (
              <>
                <div className="flex justify-between text-slate-400 text-sm">
                  <span>Recibido</span>
                  <span>{formatCurrency(sale.payment_received)}</span>
                </div>
                <div className="flex justify-between text-green-400 text-sm">
                  <span>Cambio</span>
                  <span>{formatCurrency(sale.change_given)}</span>
                </div>
              </>
            )}
          </div>
          
          {sale.notes && (
            <div>
              <p className="text-sm text-slate-400">Notas</p>
              <p className="text-slate-300 bg-slate-900/50 rounded-lg p-3 mt-1">{sale.notes}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Modal de detalle de sesión de caja
const SessionDetailModal = ({ session, onClose }) => {
  const [sessionSales, setSessionSales] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    if (session) {
      loadSessionSales();
    }
  }, [session]);
  
  const loadSessionSales = async () => {
    try {
      // Cargar ventas de la sesión
      const res = await sales.list({ limit: 100 });
      const filtered = res.data.sales.filter(s => s.cash_session_id === session.id);
      setSessionSales(filtered);
    } catch (err) {
      console.error('Error loading session sales:', err);
    } finally {
      setLoading(false);
    }
  };
  
  if (!session) return null;
  
  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <div>
            <h2 className="text-xl font-bold text-white">Sesión de Caja</h2>
            <p className="text-sm text-slate-400">{session.register_name}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <HiOutlineX className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-6 space-y-6">
          {/* Info de la sesión */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-900/50 rounded-lg p-4">
              <p className="text-sm text-slate-400">Estado</p>
              <StatusBadge status={session.status} />
            </div>
            <div className="bg-slate-900/50 rounded-lg p-4">
              <p className="text-sm text-slate-400">Apertura</p>
              <p className="text-white">{formatDateTime(session.opened_at)}</p>
            </div>
            <div className="bg-slate-900/50 rounded-lg p-4">
              <p className="text-sm text-slate-400">Cierre</p>
              <p className="text-white">{session.closed_at ? formatDateTime(session.closed_at) : '-'}</p>
            </div>
            <div className="bg-slate-900/50 rounded-lg p-4">
              <p className="text-sm text-slate-400">Empleado</p>
              <p className="text-white">{session.employee_name || 'No asignado'}</p>
            </div>
          </div>
          
          {/* Montos */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
              <p className="text-sm text-green-400">Monto Apertura</p>
              <p className="text-xl font-bold text-white">{formatCurrency(session.opening_amount)}</p>
            </div>
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
              <p className="text-sm text-blue-400">Esperado</p>
              <p className="text-xl font-bold text-white">{formatCurrency(session.expected_amount)}</p>
            </div>
            <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
              <p className="text-sm text-purple-400">Contado</p>
              <p className="text-xl font-bold text-white">{formatCurrency(session.closing_amount)}</p>
            </div>
            <div className={`${session.difference >= 0 ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'} border rounded-lg p-4`}>
              <p className={`text-sm ${session.difference >= 0 ? 'text-green-400' : 'text-red-400'}`}>Diferencia</p>
              <p className="text-xl font-bold text-white">{formatCurrency(session.difference)}</p>
            </div>
          </div>
          
          {/* Ventas de la sesión */}
          <div>
            <h3 className="font-medium text-white mb-3">Ventas de la Sesión ({sessionSales.length})</h3>
            {loading ? (
              <div className="text-center py-8 text-slate-400">Cargando ventas...</div>
            ) : sessionSales.length === 0 ? (
              <div className="text-center py-8 text-slate-400">No hay ventas en esta sesión</div>
            ) : (
              <div className="bg-slate-900/50 rounded-lg overflow-hidden max-h-64 overflow-y-auto">
                <table className="w-full">
                  <thead className="sticky top-0 bg-slate-900">
                    <tr className="border-b border-slate-700">
                      <th className="text-left p-3 text-sm text-slate-400">Hora</th>
                      <th className="text-left p-3 text-sm text-slate-400">Pago</th>
                      <th className="text-right p-3 text-sm text-slate-400">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sessionSales.map((sale) => (
                      <tr key={sale.id} className="border-b border-slate-700/50">
                        <td className="p-3 text-white">{formatTime(sale.created_at)}</td>
                        <td className="p-3"><PaymentMethodBadge method={sale.payment_method} /></td>
                        <td className="p-3 text-right text-white font-medium">{formatCurrency(sale.total)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
          
          {session.notes && (
            <div>
              <p className="text-sm text-slate-400">Notas</p>
              <p className="text-slate-300 bg-slate-900/50 rounded-lg p-3 mt-1">{session.notes}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// ==================== COMPONENTE PRINCIPAL ====================

export default function Sales() {
  const [activeTab, setActiveTab] = useState('history');
  const [loading, setLoading] = useState(false);
  
  // Estado de datos
  const [salesData, setSalesData] = useState({ sales: [], total: 0 });
  const [sessionsData, setSessionsData] = useState([]);
  const [todaySummary, setTodaySummary] = useState(null);
  const [dailyReport, setDailyReport] = useState(null);
  const [employeesList, setEmployeesList] = useState([]);
  
  // Filtros
  const [filters, setFilters] = useState({
    start_date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    end_date: new Date().toISOString().split('T')[0],
    employee_id: '',
    status: '',
    payment_method: ''
  });
  
  // Modales
  const [selectedSale, setSelectedSale] = useState(null);
  const [selectedSession, setSelectedSession] = useState(null);
  
  const tabs = [
    { id: 'history', name: 'Historial', icon: HiOutlineShoppingCart },
    { id: 'sessions', name: 'Sesiones de Caja', icon: HiOutlineCash },
    { id: 'analytics', name: 'Analíticas', icon: HiOutlineChartBar }
  ];
  
  useEffect(() => {
    loadEmployees();
    loadTodaySummary();
  }, []);
  
  useEffect(() => {
    if (activeTab === 'history') {
      loadSales();
    } else if (activeTab === 'sessions') {
      loadSessions();
    } else if (activeTab === 'analytics') {
      loadAnalytics();
    }
  }, [activeTab, filters]);
  
  const loadEmployees = async () => {
    try {
      const res = await employees.list();
      setEmployeesList(res.data.employees || []);
    } catch (err) {
      console.error('Error loading employees:', err);
    }
  };
  
  const loadTodaySummary = async () => {
    try {
      const res = await sales.today();
      setTodaySummary(res.data);
    } catch (err) {
      console.error('Error loading today summary:', err);
    }
  };
  
  const loadSales = async () => {
    setLoading(true);
    try {
      const params = {
        start_date: filters.start_date,
        end_date: filters.end_date,
        limit: 50
      };
      if (filters.employee_id) params.employee_id = filters.employee_id;
      if (filters.status) params.status = filters.status;
      
      const res = await sales.list(params);
      
      // Filtrar por método de pago en cliente si es necesario
      let filteredSales = res.data.sales || [];
      if (filters.payment_method) {
        filteredSales = filteredSales.filter(s => s.payment_method === filters.payment_method);
      }
      
      setSalesData({ sales: filteredSales, total: res.data.total });
    } catch (err) {
      console.error('Error loading sales:', err);
    } finally {
      setLoading(false);
    }
  };
  
  const loadSessions = async () => {
    setLoading(true);
    try {
      const res = await sales.listSessions({ limit: 30 });
      setSessionsData(res.data.sessions || []);
    } catch (err) {
      console.error('Error loading sessions:', err);
    } finally {
      setLoading(false);
    }
  };
  
  const loadAnalytics = async () => {
    setLoading(true);
    try {
      const res = await reports.salesDaily({
        start_date: filters.start_date,
        end_date: filters.end_date
      });
      setDailyReport(res.data.report);
    } catch (err) {
      console.error('Error loading analytics:', err);
    } finally {
      setLoading(false);
    }
  };
  
  const viewSaleDetail = async (saleId) => {
    try {
      const res = await sales.get(saleId);
      setSelectedSale(res.data.sale);
    } catch (err) {
      console.error('Error loading sale detail:', err);
    }
  };
  
  const handleFilterChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };
  
  // ==================== RENDER TABS ====================
  
  // Tab: Historial de Ventas
  const renderHistory = () => (
    <div className="space-y-6">
      {/* Resumen del día */}
      {todaySummary && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard
            icon={HiOutlineShoppingCart}
            title="Ventas Hoy"
            value={todaySummary.summary?.total_sales || 0}
            subtitle={formatCurrency(todaySummary.summary?.total_amount)}
            color="purple"
          />
          <StatCard
            icon={HiOutlineCash}
            title="Efectivo"
            value={formatCurrency(todaySummary.summary?.cash_amount)}
            color="green"
          />
          <StatCard
            icon={HiOutlineCreditCard}
            title="Tarjeta"
            value={formatCurrency(todaySummary.summary?.card_amount)}
            color="blue"
          />
          <StatCard
            icon={HiOutlineReceiptRefund}
            title="Transferencia"
            value={formatCurrency(todaySummary.summary?.transfer_amount)}
            color="yellow"
          />
        </div>
      )}
      
      {/* Filtros */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-4">
          <HiOutlineFilter className="w-5 h-5 text-slate-400" />
          <span className="text-white font-medium">Filtros</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div>
            <label className="block text-sm text-slate-400 mb-1">Desde</label>
            <input
              type="date"
              value={filters.start_date}
              onChange={(e) => handleFilterChange('start_date', e.target.value)}
              className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-1">Hasta</label>
            <input
              type="date"
              value={filters.end_date}
              onChange={(e) => handleFilterChange('end_date', e.target.value)}
              className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-1">Empleado</label>
            <select
              value={filters.employee_id}
              onChange={(e) => handleFilterChange('employee_id', e.target.value)}
              className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
            >
              <option value="">Todos</option>
              {employeesList.map(emp => (
                <option key={emp.id} value={emp.id}>{emp.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-1">Estado</label>
            <select
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
              className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
            >
              <option value="">Todos</option>
              <option value="completed">Completada</option>
              <option value="cancelled">Cancelada</option>
            </select>
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-1">Pago</label>
            <select
              value={filters.payment_method}
              onChange={(e) => handleFilterChange('payment_method', e.target.value)}
              className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
            >
              <option value="">Todos</option>
              <option value="efectivo">Efectivo</option>
              <option value="tarjeta">Tarjeta</option>
              <option value="transferencia">Transferencia</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Tabla de ventas */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-700 flex items-center justify-between">
          <h3 className="font-medium text-white">Historial de Ventas</h3>
          <span className="text-sm text-slate-400">{salesData.total} ventas encontradas</span>
        </div>
        
        {loading ? (
          <div className="p-8 text-center text-slate-400">Cargando ventas...</div>
        ) : salesData.sales.length === 0 ? (
          <div className="p-8 text-center text-slate-400">No hay ventas en el período seleccionado</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-900/50">
                <tr>
                  <th className="text-left p-4 text-sm text-slate-400 font-medium">Fecha</th>
                  <th className="text-left p-4 text-sm text-slate-400 font-medium">Vendedor</th>
                  <th className="text-left p-4 text-sm text-slate-400 font-medium">Pago</th>
                  <th className="text-right p-4 text-sm text-slate-400 font-medium">Total</th>
                  <th className="text-center p-4 text-sm text-slate-400 font-medium">Estado</th>
                  <th className="text-center p-4 text-sm text-slate-400 font-medium">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {salesData.sales.map((sale) => (
                  <tr key={sale.id} className="hover:bg-slate-700/30 transition-colors">
                    <td className="p-4">
                      <div className="text-white">{formatDate(sale.created_at)}</div>
                      <div className="text-xs text-slate-400">{formatTime(sale.created_at)}</div>
                    </td>
                    <td className="p-4 text-slate-300">{sale.employee_name || '-'}</td>
                    <td className="p-4"><PaymentMethodBadge method={sale.payment_method} /></td>
                    <td className="p-4 text-right text-white font-medium">{formatCurrency(sale.total)}</td>
                    <td className="p-4 text-center"><StatusBadge status={sale.status} /></td>
                    <td className="p-4 text-center">
                      <button
                        onClick={() => viewSaleDetail(sale.id)}
                        className="text-purple-400 hover:text-purple-300 p-2"
                        title="Ver detalle"
                      >
                        <HiOutlineEye className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
  
  // Tab: Sesiones de Caja
  const renderSessions = () => (
    <div className="space-y-6">
      {/* Stats de sesiones */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          icon={HiOutlineCash}
          title="Sesiones Abiertas"
          value={sessionsData.filter(s => s.status === 'open').length}
          color="green"
        />
        <StatCard
          icon={HiOutlineCheckCircle}
          title="Cerradas Hoy"
          value={sessionsData.filter(s => s.status === 'closed' && s.closed_at?.includes(new Date().toISOString().split('T')[0])).length}
          color="blue"
        />
        <StatCard
          icon={HiOutlineExclamationCircle}
          title="Con Diferencia"
          value={sessionsData.filter(s => s.difference && Math.abs(s.difference) > 1).length}
          color="yellow"
        />
        <StatCard
          icon={HiOutlineClock}
          title="Total Sesiones"
          value={sessionsData.length}
          color="purple"
        />
      </div>
      
      {/* Lista de sesiones */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-700 flex items-center justify-between">
          <h3 className="font-medium text-white">Sesiones de Caja</h3>
          <button 
            onClick={loadSessions}
            className="text-slate-400 hover:text-white"
            title="Refrescar"
          >
            <HiOutlineRefresh className="w-5 h-5" />
          </button>
        </div>
        
        {loading ? (
          <div className="p-8 text-center text-slate-400">Cargando sesiones...</div>
        ) : sessionsData.length === 0 ? (
          <div className="p-8 text-center text-slate-400">No hay sesiones registradas</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-900/50">
                <tr>
                  <th className="text-left p-4 text-sm text-slate-400 font-medium">Caja</th>
                  <th className="text-left p-4 text-sm text-slate-400 font-medium">Empleado</th>
                  <th className="text-left p-4 text-sm text-slate-400 font-medium">Apertura</th>
                  <th className="text-left p-4 text-sm text-slate-400 font-medium">Cierre</th>
                  <th className="text-right p-4 text-sm text-slate-400 font-medium">Apertura $</th>
                  <th className="text-right p-4 text-sm text-slate-400 font-medium">Cierre $</th>
                  <th className="text-right p-4 text-sm text-slate-400 font-medium">Diferencia</th>
                  <th className="text-center p-4 text-sm text-slate-400 font-medium">Estado</th>
                  <th className="text-center p-4 text-sm text-slate-400 font-medium">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {sessionsData.map((session) => (
                  <tr key={session.id} className="hover:bg-slate-700/30 transition-colors">
                    <td className="p-4 text-white font-medium">{session.register_name}</td>
                    <td className="p-4 text-slate-300">{session.employee_name || '-'}</td>
                    <td className="p-4 text-slate-300">{formatDateTime(session.opened_at)}</td>
                    <td className="p-4 text-slate-300">{session.closed_at ? formatDateTime(session.closed_at) : '-'}</td>
                    <td className="p-4 text-right text-white">{formatCurrency(session.opening_amount)}</td>
                    <td className="p-4 text-right text-white">{session.closing_amount ? formatCurrency(session.closing_amount) : '-'}</td>
                    <td className={`p-4 text-right font-medium ${
                      session.difference > 0 ? 'text-green-400' : 
                      session.difference < 0 ? 'text-red-400' : 'text-slate-400'
                    }`}>
                      {session.difference !== null ? formatCurrency(session.difference) : '-'}
                    </td>
                    <td className="p-4 text-center"><StatusBadge status={session.status} /></td>
                    <td className="p-4 text-center">
                      <button
                        onClick={() => setSelectedSession(session)}
                        className="text-purple-400 hover:text-purple-300 p-2"
                        title="Ver detalle"
                      >
                        <HiOutlineEye className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
  
  // Tab: Analíticas
  const renderAnalytics = () => (
    <div className="space-y-6">
      {/* Filtros de período */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <HiOutlineCalendar className="w-5 h-5 text-slate-400" />
            <span className="text-white">Período:</span>
          </div>
          <input
            type="date"
            value={filters.start_date}
            onChange={(e) => handleFilterChange('start_date', e.target.value)}
            className="bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
          />
          <span className="text-slate-400">a</span>
          <input
            type="date"
            value={filters.end_date}
            onChange={(e) => handleFilterChange('end_date', e.target.value)}
            className="bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
          />
          <button
            onClick={loadAnalytics}
            className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2"
          >
            <HiOutlineRefresh className="w-4 h-4" />
            Actualizar
          </button>
        </div>
      </div>
      
      {loading ? (
        <div className="p-8 text-center text-slate-400">Cargando analíticas...</div>
      ) : dailyReport ? (
        <>
          {/* Resumen del período */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard
              icon={HiOutlineShoppingCart}
              title="Total Transacciones"
              value={dailyReport.totals?.total_transactions || 0}
              color="purple"
            />
            <StatCard
              icon={HiOutlineCash}
              title="Ventas Totales"
              value={formatCurrency(dailyReport.totals?.total_sales)}
              color="green"
            />
            <StatCard
              icon={HiOutlineTrendingUp}
              title="Ticket Promedio"
              value={formatCurrency(dailyReport.totals?.avg_ticket)}
              color="blue"
            />
            <StatCard
              icon={HiOutlineCalendar}
              title="Días con Ventas"
              value={dailyReport.daily?.length || 0}
              color="yellow"
            />
          </div>
          
          {/* Tabla de ventas diarias */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-700">
              <h3 className="font-medium text-white">Ventas Diarias</h3>
            </div>
            
            {dailyReport.daily?.length === 0 ? (
              <div className="p-8 text-center text-slate-400">No hay datos en el período</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-900/50">
                    <tr>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">Fecha</th>
                      <th className="text-center p-4 text-sm text-slate-400 font-medium">Transacciones</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Efectivo</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Tarjeta</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Transferencia</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Total</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Ticket Prom.</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/50">
                    {dailyReport.daily?.map((day) => (
                      <tr key={day.date} className="hover:bg-slate-700/30 transition-colors">
                        <td className="p-4 text-white font-medium">{formatDate(day.date)}</td>
                        <td className="p-4 text-center text-slate-300">{day.transactions}</td>
                        <td className="p-4 text-right text-green-400">{formatCurrency(day.cash_sales)}</td>
                        <td className="p-4 text-right text-blue-400">{formatCurrency(day.card_sales)}</td>
                        <td className="p-4 text-right text-purple-400">{formatCurrency(day.transfer_sales)}</td>
                        <td className="p-4 text-right text-white font-bold">{formatCurrency(day.total_sales)}</td>
                        <td className="p-4 text-right text-slate-300">{formatCurrency(day.avg_ticket)}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-slate-900/70">
                    <tr>
                      <td className="p-4 text-white font-bold">TOTAL</td>
                      <td className="p-4 text-center text-white font-bold">{dailyReport.totals?.total_transactions}</td>
                      <td className="p-4 text-right text-green-400 font-bold">
                        {formatCurrency(dailyReport.daily?.reduce((sum, d) => sum + (d.cash_sales || 0), 0))}
                      </td>
                      <td className="p-4 text-right text-blue-400 font-bold">
                        {formatCurrency(dailyReport.daily?.reduce((sum, d) => sum + (d.card_sales || 0), 0))}
                      </td>
                      <td className="p-4 text-right text-purple-400 font-bold">
                        {formatCurrency(dailyReport.daily?.reduce((sum, d) => sum + (d.transfer_sales || 0), 0))}
                      </td>
                      <td className="p-4 text-right text-white font-bold">{formatCurrency(dailyReport.totals?.total_sales)}</td>
                      <td className="p-4 text-right text-white font-bold">{formatCurrency(dailyReport.totals?.avg_ticket)}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>
          
          {/* Gráfico simple de barras (CSS bars) */}
          {dailyReport.daily?.length > 0 && (
            <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
              <h3 className="font-medium text-white mb-4">Tendencia de Ventas</h3>
              <div className="flex items-end gap-2 h-48 overflow-x-auto pb-4">
                {dailyReport.daily?.slice(-14).map((day) => {
                  const maxSales = Math.max(...dailyReport.daily.slice(-14).map(d => d.total_sales || 0));
                  const height = maxSales > 0 ? ((day.total_sales || 0) / maxSales) * 100 : 0;
                  return (
                    <div key={day.date} className="flex flex-col items-center min-w-[40px]">
                      <div 
                        className="w-8 bg-gradient-to-t from-purple-600 to-purple-400 rounded-t transition-all"
                        style={{ height: `${height}%`, minHeight: '4px' }}
                        title={`${formatDate(day.date)}: ${formatCurrency(day.total_sales)}`}
                      />
                      <span className="text-xs text-slate-500 mt-2 -rotate-45 origin-left whitespace-nowrap">
                        {new Date(day.date).toLocaleDateString('es-MX', { day: '2-digit', month: 'short' })}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="p-8 text-center text-slate-400">Selecciona un período para ver analíticas</div>
      )}
    </div>
  );
  
  // ==================== RENDER PRINCIPAL ====================
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Ventas</h1>
        <p className="text-slate-400">Historial de ventas, sesiones de caja y análisis</p>
      </div>
      
      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-700 pb-2 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-purple-600 text-white'
                : 'text-slate-400 hover:bg-slate-700/50 hover:text-white'
            }`}
          >
            <tab.icon className="w-5 h-5" />
            {tab.name}
          </button>
        ))}
      </div>
      
      {/* Tab Content */}
      {activeTab === 'history' && renderHistory()}
      {activeTab === 'sessions' && renderSessions()}
      {activeTab === 'analytics' && renderAnalytics()}
      
      {/* Modales */}
      {selectedSale && (
        <SaleDetailModal sale={selectedSale} onClose={() => setSelectedSale(null)} />
      )}
      {selectedSession && (
        <SessionDetailModal session={selectedSession} onClose={() => setSelectedSession(null)} />
      )}
    </div>
  );
}
