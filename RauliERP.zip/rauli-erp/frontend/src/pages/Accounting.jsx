/**
 * Rauli ERP - Accounting Page
 */

import { useState, useEffect } from 'react';
import { 
  HiOutlineCurrencyDollar, HiOutlineRefresh, HiOutlineDocumentText,
  HiOutlineChartPie, HiOutlineLibrary, HiOutlineCreditCard, HiOutlineScale
} from 'react-icons/hi';
import { accounting } from '../services/api';

const TABS = [
  { id: 'dashboard', label: 'Dashboard', icon: HiOutlineChartPie },
  { id: 'accounts', label: 'Plan de Cuentas', icon: HiOutlineLibrary },
  { id: 'entries', label: 'Asientos', icon: HiOutlineDocumentText },
  { id: 'bank', label: 'Bancos', icon: HiOutlineCreditCard },
  { id: 'reports', label: 'Reportes', icon: HiOutlineScale },
];

export default function Accounting() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  const [dashboard, setDashboard] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [entries, setEntries] = useState([]);
  const [bankAccounts, setBankAccounts] = useState([]);
  const [bankTransactions, setBankTransactions] = useState([]);
  const [balanceSheet, setBalanceSheet] = useState(null);
  const [incomeStatement, setIncomeStatement] = useState(null);

  useEffect(() => { loadData(); }, []);

  useEffect(() => {
    if (activeTab === 'accounts') loadAccounts();
    if (activeTab === 'entries') loadEntries();
    if (activeTab === 'bank') loadBankData();
    if (activeTab === 'reports') loadReports();
  }, [activeTab]);

  const loadData = async () => {
    setLoading(true);
    try {
      const res = await accounting.dashboard();
      setDashboard(res.data.dashboard);
    } catch (err) {
      console.error('Error loading accounting data:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadAccounts = async () => {
    try {
      const res = await accounting.accounts();
      setAccounts(res.data.accounts || []);
    } catch (err) { console.error('Error loading accounts:', err); }
  };

  const loadEntries = async () => {
    try {
      const res = await accounting.entries({ limit: 50 });
      setEntries(res.data.entries || []);
    } catch (err) { console.error('Error loading entries:', err); }
  };

  const loadBankData = async () => {
    try {
      const [accRes, transRes] = await Promise.all([
        accounting.bankAccounts(),
        accounting.bankTransactions({ limit: 50 })
      ]);
      setBankAccounts(accRes.data.accounts || []);
      setBankTransactions(transRes.data.transactions || []);
    } catch (err) { console.error('Error loading bank data:', err); }
  };

  const loadReports = async () => {
    try {
      const [balRes, incRes] = await Promise.all([
        accounting.balanceSheet({}),
        accounting.incomeStatement({})
      ]);
      setBalanceSheet(balRes.data.balance);
      setIncomeStatement(balRes.data.income_statement || incRes.data.income_statement);
    } catch (err) { console.error('Error loading reports:', err); }
  };

  const formatCurrency = (amount) => new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(amount || 0);
  const formatDate = (date) => date ? new Date(date).toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' }) : '-';

  const getAccountTypeLabel = (type) => {
    const types = { 'activo': 'Activo', 'pasivo': 'Pasivo', 'patrimonio': 'Patrimonio', 'ingreso': 'Ingreso', 'gasto': 'Gasto' };
    return types[type] || type;
  };

  const getAccountTypeColor = (type) => {
    const colors = {
      'activo': 'bg-blue-500/20 text-blue-400',
      'pasivo': 'bg-red-500/20 text-red-400',
      'patrimonio': 'bg-purple-500/20 text-purple-400',
      'ingreso': 'bg-green-500/20 text-green-400',
      'gasto': 'bg-yellow-500/20 text-yellow-400',
    };
    return colors[type] || 'bg-slate-500/20 text-slate-400';
  };

  // ==================== TAB COMPONENTS ====================
  const DashboardTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Ventas del Mes" value={formatCurrency(dashboard?.monthly_sales)} icon={HiOutlineCurrencyDollar} color="green" />
        <StatCard title="Por Conciliar" value={dashboard?.pending_reconciliation?.count || 0} icon={HiOutlineCreditCard} color="yellow" />
        <StatCard title="Monto Pendiente" value={formatCurrency(dashboard?.pending_reconciliation?.total)} icon={HiOutlineScale} color="red" />
        <StatCard title="Últimos Asientos" value={dashboard?.recent_entries?.length || 0} icon={HiOutlineDocumentText} color="blue" />
      </div>

      {/* Account Balances by Type */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
        <h3 className="font-semibold text-white mb-4">Balance por Tipo de Cuenta</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {(dashboard?.account_balances || []).map(ab => (
            <div key={ab.type} className="text-center">
              <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium mb-2 ${getAccountTypeColor(ab.type)}`}>
                {getAccountTypeLabel(ab.type)}
              </span>
              <p className="text-xl font-bold text-white">{formatCurrency(ab.total)}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Entries */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
        <h3 className="font-semibold text-white mb-4">Asientos Recientes</h3>
        <div className="space-y-2">
          {(dashboard?.recent_entries || []).map(entry => (
            <div key={entry.id} className="flex justify-between items-center py-2 border-b border-slate-700/50 last:border-0">
              <div>
                <span className="text-white font-medium">#{entry.entry_number}</span>
                <span className="text-slate-400 ml-3">{entry.description}</span>
              </div>
              <div className="text-right">
                <span className="text-green-400 font-medium">{formatCurrency(entry.total_amount)}</span>
                <span className="text-slate-500 ml-3 text-sm">{formatDate(entry.date)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const AccountsTab = () => (
    <div className="space-y-4">
      <p className="text-slate-400">Plan de cuentas contables</p>
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-700/50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Código</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Nombre</th>
              <th className="px-4 py-3 text-center text-sm font-medium text-slate-300">Tipo</th>
              <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">Balance</th>
            </tr>
          </thead>
          <tbody>
            {accounts.map(acc => (
              <tr key={acc.id} className="border-t border-slate-700/50 hover:bg-slate-700/30">
                <td className="px-4 py-3 text-indigo-400 font-mono">{acc.code}</td>
                <td className="px-4 py-3 text-white">{acc.name}</td>
                <td className="px-4 py-3 text-center">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getAccountTypeColor(acc.type)}`}>
                    {getAccountTypeLabel(acc.type)}
                  </span>
                </td>
                <td className={`px-4 py-3 text-right font-medium ${acc.balance >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {formatCurrency(acc.balance)}
                </td>
              </tr>
            ))}
            {accounts.length === 0 && <tr><td colSpan={4} className="px-4 py-8 text-center text-slate-500">No hay cuentas registradas</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );

  const EntriesTab = () => (
    <div className="space-y-4">
      <p className="text-slate-400">Asientos contables (Libro Diario)</p>
      <div className="space-y-4">
        {entries.map(entry => (
          <div key={entry.id} className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
            <div className="bg-slate-700/50 px-4 py-3 flex justify-between items-center">
              <div>
                <span className="text-indigo-400 font-mono font-bold">#{entry.entry_number}</span>
                <span className="text-white ml-3">{entry.description}</span>
              </div>
              <div className="text-right">
                <span className="text-slate-400 text-sm">{formatDate(entry.date)}</span>
                <span className={`ml-3 px-2 py-1 rounded text-xs ${entry.status === 'posted' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                  {entry.status}
                </span>
              </div>
            </div>
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700/50">
                  <th className="px-4 py-2 text-left text-xs text-slate-500">Cuenta</th>
                  <th className="px-4 py-2 text-right text-xs text-slate-500">Debe</th>
                  <th className="px-4 py-2 text-right text-xs text-slate-500">Haber</th>
                </tr>
              </thead>
              <tbody>
                {(entry.lines || []).map((line, idx) => (
                  <tr key={idx} className="border-b border-slate-700/30 last:border-0">
                    <td className="px-4 py-2">
                      <span className="text-slate-500 font-mono text-sm">{line.account_code}</span>
                      <span className="text-white ml-2">{line.account_name}</span>
                    </td>
                    <td className="px-4 py-2 text-right text-green-400">{line.debit > 0 ? formatCurrency(line.debit) : ''}</td>
                    <td className="px-4 py-2 text-right text-red-400">{line.credit > 0 ? formatCurrency(line.credit) : ''}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
        {entries.length === 0 && (
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-12 text-center">
            <HiOutlineDocumentText className="w-12 h-12 mx-auto text-slate-600 mb-3" />
            <p className="text-slate-400">No hay asientos registrados</p>
          </div>
        )}
      </div>
    </div>
  );

  const BankTab = () => (
    <div className="space-y-6">
      {/* Bank Accounts */}
      <div>
        <h3 className="font-semibold text-white mb-4">Cuentas Bancarias</h3>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {bankAccounts.map(acc => (
            <div key={acc.id} className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h4 className="text-white font-medium">{acc.name}</h4>
                  <p className="text-slate-500 text-sm">{acc.bank_name}</p>
                </div>
                <HiOutlineCreditCard className="w-6 h-6 text-indigo-400" />
              </div>
              <p className="text-slate-400 text-sm font-mono mb-2">****{acc.account_number?.slice(-4)}</p>
              <p className={`text-2xl font-bold ${acc.balance >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {formatCurrency(acc.balance)}
              </p>
              {acc.pending_count > 0 && (
                <p className="text-yellow-400 text-sm mt-2">{acc.pending_count} transacciones por conciliar</p>
              )}
            </div>
          ))}
          {bankAccounts.length === 0 && (
            <div className="col-span-full text-center py-8 text-slate-500">
              No hay cuentas bancarias registradas
            </div>
          )}
        </div>
      </div>

      {/* Transactions */}
      <div>
        <h3 className="font-semibold text-white mb-4">Transacciones Recientes</h3>
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-700/50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Fecha</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Cuenta</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Descripción</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">Monto</th>
                <th className="px-4 py-3 text-center text-sm font-medium text-slate-300">Conciliado</th>
              </tr>
            </thead>
            <tbody>
              {bankTransactions.map(tx => (
                <tr key={tx.id} className="border-t border-slate-700/50 hover:bg-slate-700/30">
                  <td className="px-4 py-3 text-slate-300">{formatDate(tx.date)}</td>
                  <td className="px-4 py-3 text-white">{tx.account_name}</td>
                  <td className="px-4 py-3 text-slate-400">{tx.description || '-'}</td>
                  <td className={`px-4 py-3 text-right font-medium ${tx.amount >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {formatCurrency(tx.amount)}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${tx.reconciled ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                      {tx.reconciled ? '✓' : 'Pendiente'}
                    </span>
                  </td>
                </tr>
              ))}
              {bankTransactions.length === 0 && <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-500">No hay transacciones</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const ReportsTab = () => (
    <div className="space-y-6">
      {/* Balance Sheet */}
      {balanceSheet && (
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
          <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
            <HiOutlineScale className="w-5 h-5 text-indigo-400" />
            Balance General
          </h3>
          <div className="grid md:grid-cols-3 gap-6">
            {/* Activos */}
            <div>
              <h4 className="text-blue-400 font-medium mb-3 pb-2 border-b border-slate-700">ACTIVOS</h4>
              <div className="space-y-2">
                {(balanceSheet.activos || []).map(acc => (
                  <div key={acc.code} className="flex justify-between text-sm">
                    <span className="text-slate-300">{acc.name}</span>
                    <span className="text-white">{formatCurrency(acc.balance)}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between font-bold mt-3 pt-2 border-t border-slate-700">
                <span className="text-blue-400">Total Activos</span>
                <span className="text-white">{formatCurrency(balanceSheet.totals?.activos)}</span>
              </div>
            </div>

            {/* Pasivos */}
            <div>
              <h4 className="text-red-400 font-medium mb-3 pb-2 border-b border-slate-700">PASIVOS</h4>
              <div className="space-y-2">
                {(balanceSheet.pasivos || []).map(acc => (
                  <div key={acc.code} className="flex justify-between text-sm">
                    <span className="text-slate-300">{acc.name}</span>
                    <span className="text-white">{formatCurrency(acc.balance)}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between font-bold mt-3 pt-2 border-t border-slate-700">
                <span className="text-red-400">Total Pasivos</span>
                <span className="text-white">{formatCurrency(balanceSheet.totals?.pasivos)}</span>
              </div>
            </div>

            {/* Patrimonio */}
            <div>
              <h4 className="text-purple-400 font-medium mb-3 pb-2 border-b border-slate-700">PATRIMONIO</h4>
              <div className="space-y-2">
                {(balanceSheet.patrimonio || []).map(acc => (
                  <div key={acc.code} className="flex justify-between text-sm">
                    <span className="text-slate-300">{acc.name}</span>
                    <span className="text-white">{formatCurrency(acc.balance)}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between font-bold mt-3 pt-2 border-t border-slate-700">
                <span className="text-purple-400">Total Patrimonio</span>
                <span className="text-white">{formatCurrency(balanceSheet.totals?.patrimonio)}</span>
              </div>
            </div>
          </div>

          {/* Balance Check */}
          <div className="mt-6 p-4 bg-slate-700/30 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-slate-300">Activos = Pasivos + Patrimonio</span>
              <span className={`font-bold ${Math.abs(balanceSheet.totals?.activos - (balanceSheet.totals?.pasivos + balanceSheet.totals?.patrimonio)) < 0.01 ? 'text-green-400' : 'text-red-400'}`}>
                {formatCurrency(balanceSheet.totals?.activos)} = {formatCurrency(balanceSheet.totals?.pasivos + balanceSheet.totals?.patrimonio)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Income Statement */}
      {incomeStatement && (
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
          <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
            <HiOutlineChartPie className="w-5 h-5 text-green-400" />
            Estado de Resultados
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            {/* Ingresos */}
            <div>
              <h4 className="text-green-400 font-medium mb-3 pb-2 border-b border-slate-700">INGRESOS</h4>
              <div className="space-y-2">
                {(incomeStatement.ingresos || []).map(acc => (
                  <div key={acc.code} className="flex justify-between text-sm">
                    <span className="text-slate-300">{acc.name}</span>
                    <span className="text-green-400">{formatCurrency(acc.amount)}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between font-bold mt-3 pt-2 border-t border-slate-700">
                <span className="text-green-400">Total Ingresos</span>
                <span className="text-white">{formatCurrency(incomeStatement.totals?.ingresos)}</span>
              </div>
            </div>

            {/* Gastos */}
            <div>
              <h4 className="text-yellow-400 font-medium mb-3 pb-2 border-b border-slate-700">GASTOS</h4>
              <div className="space-y-2">
                {(incomeStatement.gastos || []).map(acc => (
                  <div key={acc.code} className="flex justify-between text-sm">
                    <span className="text-slate-300">{acc.name}</span>
                    <span className="text-red-400">{formatCurrency(acc.amount)}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between font-bold mt-3 pt-2 border-t border-slate-700">
                <span className="text-yellow-400">Total Gastos</span>
                <span className="text-white">{formatCurrency(incomeStatement.totals?.gastos)}</span>
              </div>
            </div>
          </div>

          {/* Net Income */}
          <div className="mt-6 p-4 bg-slate-700/30 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-xl font-bold text-white">Utilidad Neta</span>
              <span className={`text-2xl font-bold ${(incomeStatement.totals?.utilidad || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {formatCurrency(incomeStatement.totals?.utilidad)}
              </span>
            </div>
          </div>
        </div>
      )}

      {!balanceSheet && !incomeStatement && (
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-12 text-center">
          <HiOutlineChartPie className="w-12 h-12 mx-auto text-slate-600 mb-3" />
          <p className="text-slate-400">No hay datos para generar reportes</p>
        </div>
      )}
    </div>
  );

  // ==================== RENDER ====================
  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-500 border-t-transparent"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold text-white">Contabilidad</h1>
          <p className="text-slate-400">Plan de cuentas, asientos y reportes financieros</p>
        </div>
        <button onClick={loadData} className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
          <HiOutlineRefresh className="w-5 h-5" />Actualizar
        </button>
      </div>

      <div className="flex gap-1 bg-slate-800/50 p-1 rounded-lg overflow-x-auto">
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${activeTab === tab.id ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-700/50'}`}>
            <tab.icon className="w-5 h-5" />{tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'dashboard' && <DashboardTab />}
      {activeTab === 'accounts' && <AccountsTab />}
      {activeTab === 'entries' && <EntriesTab />}
      {activeTab === 'bank' && <BankTab />}
      {activeTab === 'reports' && <ReportsTab />}
    </div>
  );
}

function StatCard({ title, value, icon: Icon, color }) {
  const colorClasses = { blue: 'bg-blue-500/20 text-blue-400', green: 'bg-green-500/20 text-green-400', yellow: 'bg-yellow-500/20 text-yellow-400', red: 'bg-red-500/20 text-red-400' };
  return (
    <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-slate-400 text-sm">{title}</span>
        <div className={`p-2 rounded-lg ${colorClasses[color]}`}><Icon className="w-5 h-5" /></div>
      </div>
      <p className="text-2xl font-bold text-white">{value}</p>
    </div>
  );
}
