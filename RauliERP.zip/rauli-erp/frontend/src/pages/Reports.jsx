/**
 * Rauli ERP - Reports Page
 * Reportes avanzados multi-módulo con exportación
 */

import { useState, useEffect } from 'react';
import {
  HiOutlineDocumentReport,
  HiOutlineChartPie,
  HiOutlineChartBar,
  HiOutlineCube,
  HiOutlineUsers,
  HiOutlineCurrencyDollar,
  HiOutlineCalendar,
  HiOutlineDownload,
  HiOutlineRefresh,
  HiOutlineTrendingUp,
  HiOutlineTrendingDown,
  HiOutlineExclamationCircle,
  HiOutlineClipboardList,
  HiOutlineCash,
  HiOutlineUserGroup,
  HiOutlineShoppingCart,
  HiOutlineFilter
} from 'react-icons/hi';
import { reports, predictions } from '../services/api';

// ==================== COMPONENTES AUXILIARES ====================

const StatCard = ({ icon: Icon, title, value, subtitle, color = 'purple', trend }) => (
  <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5">
    <div className="flex items-center justify-between">
      <div className={`p-3 rounded-lg bg-${color}-500/10`}>
        <Icon className={`w-6 h-6 text-${color}-400`} />
      </div>
      {trend !== undefined && (
        <div className={`flex items-center text-sm ${trend >= 0 ? 'text-green-400' : 'text-red-400'}`}>
          {trend >= 0 ? <HiOutlineTrendingUp className="w-4 h-4 mr-1" /> : <HiOutlineTrendingDown className="w-4 h-4 mr-1" />}
          {Math.abs(trend).toFixed(1)}%
        </div>
      )}
    </div>
    <p className="mt-4 text-2xl font-bold text-white">{value}</p>
    <p className="text-sm text-slate-400">{title}</p>
    {subtitle && <p className="text-xs text-slate-500 mt-1">{subtitle}</p>}
  </div>
);

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN'
  }).format(amount || 0);
};

const formatNumber = (num) => {
  return new Intl.NumberFormat('es-MX').format(num || 0);
};

const formatPercent = (num) => {
  return `${(num || 0).toFixed(1)}%`;
};

const formatDate = (dateString) => {
  if (!dateString) return '-';
  return new Date(dateString).toLocaleDateString('es-MX', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};

// Badge de stock
const StockBadge = ({ status }) => {
  const styles = {
    normal: 'bg-green-500/10 text-green-400 border-green-500/30',
    bajo: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30',
    sin_stock: 'bg-red-500/10 text-red-400 border-red-500/30'
  };
  const labels = {
    normal: 'Normal',
    bajo: 'Bajo',
    sin_stock: 'Sin Stock'
  };
  return (
    <span className={`px-2 py-1 rounded-lg border text-xs font-medium ${styles[status] || styles.normal}`}>
      {labels[status] || status}
    </span>
  );
};

// ==================== COMPONENTE PRINCIPAL ====================

export default function Reports() {
  const [activeTab, setActiveTab] = useState('sales');
  const [loading, setLoading] = useState(false);
  
  // Filtros comunes
  const [filters, setFilters] = useState({
    start_date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    end_date: new Date().toISOString().split('T')[0]
  });
  
  // Datos de reportes
  const [salesByProduct, setSalesByProduct] = useState([]);
  const [salesByEmployee, setSalesByEmployee] = useState([]);
  const [inventoryStatus, setInventoryStatus] = useState(null);
  const [employeePerformance, setEmployeePerformance] = useState([]);
  const [profitMargins, setProfitMargins] = useState(null);
  const [businessInsights, setBusinessInsights] = useState(null);
  
  const tabs = [
    { id: 'sales', name: 'Ventas', icon: HiOutlineShoppingCart },
    { id: 'inventory', name: 'Inventario', icon: HiOutlineCube },
    { id: 'employees', name: 'Empleados', icon: HiOutlineUsers },
    { id: 'financial', name: 'Financiero', icon: HiOutlineCurrencyDollar },
    { id: 'insights', name: 'Insights IA', icon: HiOutlineChartPie }
  ];
  
  useEffect(() => {
    loadReportData();
  }, [activeTab, filters]);
  
  const loadReportData = async () => {
    setLoading(true);
    try {
      switch (activeTab) {
        case 'sales':
          await loadSalesReports();
          break;
        case 'inventory':
          await loadInventoryReports();
          break;
        case 'employees':
          await loadEmployeeReports();
          break;
        case 'financial':
          await loadFinancialReports();
          break;
        case 'insights':
          await loadInsights();
          break;
      }
    } catch (err) {
      console.error('Error loading report:', err);
    } finally {
      setLoading(false);
    }
  };
  
  const loadSalesReports = async () => {
    const [productRes, employeeRes] = await Promise.all([
      reports.salesByProduct({ start_date: filters.start_date, end_date: filters.end_date, limit: 20 }),
      reports.salesByEmployee({ start_date: filters.start_date, end_date: filters.end_date })
    ]);
    setSalesByProduct(productRes.data.products || []);
    setSalesByEmployee(employeeRes.data.employees || []);
  };
  
  const loadInventoryReports = async () => {
    const res = await reports.inventoryStatus();
    setInventoryStatus(res.data);
  };
  
  const loadEmployeeReports = async () => {
    const res = await reports.employeePerformance({ 
      start_date: filters.start_date, 
      end_date: filters.end_date 
    });
    setEmployeePerformance(res.data.employees || []);
  };
  
  const loadFinancialReports = async () => {
    try {
      const res = await reports.salesByProduct({ 
        start_date: filters.start_date, 
        end_date: filters.end_date,
        limit: 50
      });
      // Calcular márgenes desde los datos de productos
      const products = res.data.products || [];
      const totalRevenue = products.reduce((sum, p) => sum + (p.total_revenue || 0), 0);
      const totalQuantity = products.reduce((sum, p) => sum + (p.total_quantity || 0), 0);
      
      setProfitMargins({
        products,
        totals: {
          total_revenue: totalRevenue,
          total_products: products.length,
          total_quantity: totalQuantity
        }
      });
    } catch (err) {
      console.error('Error loading financial reports:', err);
    }
  };
  
  const loadInsights = async () => {
    try {
      const res = await predictions.businessInsights();
      setBusinessInsights(res.data);
    } catch (err) {
      console.error('Error loading insights:', err);
      // Crear insights de ejemplo si el endpoint falla
      setBusinessInsights({
        summary: 'El análisis está basado en datos históricos disponibles.',
        insights: [
          { type: 'info', message: 'Conecte Ollama para obtener predicciones avanzadas con IA' }
        ]
      });
    }
  };
  
  const handleFilterChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };
  
  // Exportar a CSV
  const exportToCSV = (data, filename) => {
    if (!data || data.length === 0) return;
    
    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(','),
      ...data.map(row => headers.map(h => {
        const val = row[h];
        if (typeof val === 'string' && val.includes(',')) {
          return `"${val}"`;
        }
        return val ?? '';
      }).join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${filename}_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };
  
  // ==================== RENDER TABS ====================
  
  // Tab: Reportes de Ventas
  const renderSalesReports = () => (
    <div className="space-y-6">
      {/* Filtros */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <HiOutlineCalendar className="w-5 h-5 text-slate-400" />
            <span className="text-white">Período:</span>
          </div>
          <input
            type="date"
            value={filters.start_date}
            onChange={(e) => handleFilterChange('start_date', e.target.value)}
            className="bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
          />
          <span className="text-slate-400">a</span>
          <input
            type="date"
            value={filters.end_date}
            onChange={(e) => handleFilterChange('end_date', e.target.value)}
            className="bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
          />
          <button
            onClick={loadReportData}
            className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2"
          >
            <HiOutlineRefresh className="w-4 h-4" />
            Actualizar
          </button>
        </div>
      </div>
      
      {loading ? (
        <div className="p-8 text-center text-slate-400">Cargando reportes...</div>
      ) : (
        <>
          {/* Ventas por Producto */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between">
              <h3 className="font-medium text-white flex items-center gap-2">
                <HiOutlineChartBar className="w-5 h-5 text-purple-400" />
                Ventas por Producto
              </h3>
              <button
                onClick={() => exportToCSV(salesByProduct, 'ventas_por_producto')}
                className="text-slate-400 hover:text-white flex items-center gap-2 text-sm"
              >
                <HiOutlineDownload className="w-4 h-4" />
                Exportar CSV
              </button>
            </div>
            
            {salesByProduct.length === 0 ? (
              <div className="p-8 text-center text-slate-400">No hay datos de ventas</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-900/50">
                    <tr>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">#</th>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">Producto</th>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">Categoría</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Unidades</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Transacciones</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Ingresos</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Precio Prom.</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/50">
                    {salesByProduct.map((product, idx) => (
                      <tr key={product.product_id} className="hover:bg-slate-700/30 transition-colors">
                        <td className="p-4 text-slate-400">{idx + 1}</td>
                        <td className="p-4 text-white font-medium">{product.product_name}</td>
                        <td className="p-4 text-slate-300">{product.category_name || '-'}</td>
                        <td className="p-4 text-right text-slate-300">{formatNumber(product.total_quantity)}</td>
                        <td className="p-4 text-right text-slate-300">{formatNumber(product.transactions)}</td>
                        <td className="p-4 text-right text-green-400 font-medium">{formatCurrency(product.total_revenue)}</td>
                        <td className="p-4 text-right text-slate-300">{formatCurrency(product.avg_price)}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-slate-900/70">
                    <tr>
                      <td colSpan="3" className="p-4 text-white font-bold">TOTAL</td>
                      <td className="p-4 text-right text-white font-bold">
                        {formatNumber(salesByProduct.reduce((sum, p) => sum + (p.total_quantity || 0), 0))}
                      </td>
                      <td className="p-4 text-right text-white font-bold">
                        {formatNumber(salesByProduct.reduce((sum, p) => sum + (p.transactions || 0), 0))}
                      </td>
                      <td className="p-4 text-right text-green-400 font-bold">
                        {formatCurrency(salesByProduct.reduce((sum, p) => sum + (p.total_revenue || 0), 0))}
                      </td>
                      <td className="p-4"></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>
          
          {/* Ventas por Empleado */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between">
              <h3 className="font-medium text-white flex items-center gap-2">
                <HiOutlineUserGroup className="w-5 h-5 text-blue-400" />
                Ventas por Empleado
              </h3>
              <button
                onClick={() => exportToCSV(salesByEmployee, 'ventas_por_empleado')}
                className="text-slate-400 hover:text-white flex items-center gap-2 text-sm"
              >
                <HiOutlineDownload className="w-4 h-4" />
                Exportar CSV
              </button>
            </div>
            
            {salesByEmployee.length === 0 ? (
              <div className="p-8 text-center text-slate-400">No hay datos de empleados</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-900/50">
                    <tr>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">#</th>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">Empleado</th>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">Posición</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Transacciones</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Ventas</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Ticket Prom.</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Comisiones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/50">
                    {salesByEmployee.map((emp, idx) => (
                      <tr key={emp.employee_id} className="hover:bg-slate-700/30 transition-colors">
                        <td className="p-4 text-slate-400">{idx + 1}</td>
                        <td className="p-4 text-white font-medium">{emp.employee_name}</td>
                        <td className="p-4 text-slate-300">{emp.position || '-'}</td>
                        <td className="p-4 text-right text-slate-300">{formatNumber(emp.transactions)}</td>
                        <td className="p-4 text-right text-green-400 font-medium">{formatCurrency(emp.total_sales)}</td>
                        <td className="p-4 text-right text-slate-300">{formatCurrency(emp.avg_ticket)}</td>
                        <td className="p-4 text-right text-purple-400">{formatCurrency(emp.total_commissions)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
  
  // Tab: Reportes de Inventario
  const renderInventoryReports = () => (
    <div className="space-y-6">
      {loading ? (
        <div className="p-8 text-center text-slate-400">Cargando reportes...</div>
      ) : inventoryStatus ? (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard
              icon={HiOutlineCube}
              title="Total Productos"
              value={formatNumber(inventoryStatus.summary?.total_products)}
              color="purple"
            />
            <StatCard
              icon={HiOutlineExclamationCircle}
              title="Stock Bajo"
              value={formatNumber(inventoryStatus.summary?.low_stock)}
              color="yellow"
            />
            <StatCard
              icon={HiOutlineTrendingDown}
              title="Sin Stock"
              value={formatNumber(inventoryStatus.summary?.out_of_stock)}
              color="red"
            />
            <StatCard
              icon={HiOutlineCurrencyDollar}
              title="Valor Total"
              value={formatCurrency(inventoryStatus.summary?.total_value)}
              color="green"
            />
          </div>
          
          {/* Tabla de inventario */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between">
              <h3 className="font-medium text-white flex items-center gap-2">
                <HiOutlineClipboardList className="w-5 h-5 text-purple-400" />
                Estado del Inventario
              </h3>
              <button
                onClick={() => exportToCSV(inventoryStatus.products || [], 'inventario')}
                className="text-slate-400 hover:text-white flex items-center gap-2 text-sm"
              >
                <HiOutlineDownload className="w-4 h-4" />
                Exportar CSV
              </button>
            </div>
            
            {!inventoryStatus.products || inventoryStatus.products.length === 0 ? (
              <div className="p-8 text-center text-slate-400">No hay productos en inventario</div>
            ) : (
              <div className="overflow-x-auto max-h-96">
                <table className="w-full">
                  <thead className="bg-slate-900/50 sticky top-0">
                    <tr>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">Código</th>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">Producto</th>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">Categoría</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Stock</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Mínimo</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Costo</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Valor</th>
                      <th className="text-center p-4 text-sm text-slate-400 font-medium">Estado</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/50">
                    {inventoryStatus.products.map((product) => (
                      <tr key={product.id} className="hover:bg-slate-700/30 transition-colors">
                        <td className="p-4 text-slate-400 font-mono text-sm">{product.barcode || '-'}</td>
                        <td className="p-4 text-white font-medium">{product.name}</td>
                        <td className="p-4 text-slate-300">{product.category || '-'}</td>
                        <td className={`p-4 text-right font-medium ${
                          product.stock <= 0 ? 'text-red-400' :
                          product.stock <= product.min_stock ? 'text-yellow-400' : 'text-white'
                        }`}>
                          {formatNumber(product.stock)}
                        </td>
                        <td className="p-4 text-right text-slate-400">{formatNumber(product.min_stock)}</td>
                        <td className="p-4 text-right text-slate-300">{formatCurrency(product.cost)}</td>
                        <td className="p-4 text-right text-green-400">{formatCurrency(product.stock_value)}</td>
                        <td className="p-4 text-center"><StockBadge status={product.stock_status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
          
          {/* Alertas de stock bajo */}
          {inventoryStatus.products?.filter(p => p.stock_status !== 'normal').length > 0 && (
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-6">
              <h3 className="font-medium text-yellow-400 flex items-center gap-2 mb-4">
                <HiOutlineExclamationCircle className="w-5 h-5" />
                Alertas de Inventario
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {inventoryStatus.products
                  .filter(p => p.stock_status !== 'normal')
                  .slice(0, 9)
                  .map(product => (
                    <div key={product.id} className="bg-slate-800/50 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <span className="text-white font-medium">{product.name}</span>
                        <StockBadge status={product.stock_status} />
                      </div>
                      <div className="mt-2 text-sm text-slate-400">
                        Stock: <span className={product.stock <= 0 ? 'text-red-400' : 'text-yellow-400'}>
                          {product.stock}
                        </span> / Mínimo: {product.min_stock}
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="p-8 text-center text-slate-400">No hay datos de inventario disponibles</div>
      )}
    </div>
  );
  
  // Tab: Reportes de Empleados
  const renderEmployeeReports = () => (
    <div className="space-y-6">
      {/* Filtros */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <HiOutlineCalendar className="w-5 h-5 text-slate-400" />
            <span className="text-white">Período:</span>
          </div>
          <input
            type="date"
            value={filters.start_date}
            onChange={(e) => handleFilterChange('start_date', e.target.value)}
            className="bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
          />
          <span className="text-slate-400">a</span>
          <input
            type="date"
            value={filters.end_date}
            onChange={(e) => handleFilterChange('end_date', e.target.value)}
            className="bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
          />
          <button
            onClick={loadReportData}
            className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2"
          >
            <HiOutlineRefresh className="w-4 h-4" />
            Actualizar
          </button>
        </div>
      </div>
      
      {loading ? (
        <div className="p-8 text-center text-slate-400">Cargando reportes...</div>
      ) : (
        <>
          {/* Ranking de empleados */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between">
              <h3 className="font-medium text-white flex items-center gap-2">
                <HiOutlineUsers className="w-5 h-5 text-blue-400" />
                Desempeño de Empleados
              </h3>
              <button
                onClick={() => exportToCSV(employeePerformance, 'desempeno_empleados')}
                className="text-slate-400 hover:text-white flex items-center gap-2 text-sm"
              >
                <HiOutlineDownload className="w-4 h-4" />
                Exportar CSV
              </button>
            </div>
            
            {employeePerformance.length === 0 ? (
              <div className="p-8 text-center text-slate-400">No hay datos de desempeño</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-900/50">
                    <tr>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">Ranking</th>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">Empleado</th>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">Posición</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Ventas</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Transacciones</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Ticket Prom.</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Comisiones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/50">
                    {employeePerformance.map((emp, idx) => (
                      <tr key={emp.employee_id} className="hover:bg-slate-700/30 transition-colors">
                        <td className="p-4">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                            idx === 0 ? 'bg-yellow-500/20 text-yellow-400' :
                            idx === 1 ? 'bg-slate-400/20 text-slate-300' :
                            idx === 2 ? 'bg-orange-500/20 text-orange-400' :
                            'bg-slate-700/50 text-slate-400'
                          }`}>
                            {idx + 1}
                          </div>
                        </td>
                        <td className="p-4 text-white font-medium">{emp.employee_name}</td>
                        <td className="p-4 text-slate-300">{emp.position || '-'}</td>
                        <td className="p-4 text-right text-green-400 font-medium">{formatCurrency(emp.total_sales)}</td>
                        <td className="p-4 text-right text-slate-300">{formatNumber(emp.transactions)}</td>
                        <td className="p-4 text-right text-slate-300">{formatCurrency(emp.avg_ticket)}</td>
                        <td className="p-4 text-right text-purple-400">{formatCurrency(emp.total_commissions)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
          
          {/* Gráfico de barras visual */}
          {employeePerformance.length > 0 && (
            <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
              <h3 className="font-medium text-white mb-4">Comparativa de Ventas</h3>
              <div className="space-y-4">
                {employeePerformance.slice(0, 5).map((emp, idx) => {
                  const maxSales = Math.max(...employeePerformance.map(e => e.total_sales || 0));
                  const width = maxSales > 0 ? ((emp.total_sales || 0) / maxSales) * 100 : 0;
                  return (
                    <div key={emp.employee_id} className="flex items-center gap-4">
                      <div className="w-32 text-sm text-slate-300 truncate">{emp.employee_name}</div>
                      <div className="flex-1 h-8 bg-slate-700/50 rounded-lg overflow-hidden">
                        <div 
                          className={`h-full rounded-lg transition-all ${
                            idx === 0 ? 'bg-gradient-to-r from-yellow-600 to-yellow-400' :
                            idx === 1 ? 'bg-gradient-to-r from-slate-500 to-slate-400' :
                            idx === 2 ? 'bg-gradient-to-r from-orange-600 to-orange-400' :
                            'bg-gradient-to-r from-purple-600 to-purple-400'
                          }`}
                          style={{ width: `${width}%` }}
                        />
                      </div>
                      <div className="w-28 text-right text-sm text-white font-medium">
                        {formatCurrency(emp.total_sales)}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
  
  // Tab: Reportes Financieros
  const renderFinancialReports = () => (
    <div className="space-y-6">
      {/* Filtros */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <HiOutlineCalendar className="w-5 h-5 text-slate-400" />
            <span className="text-white">Período:</span>
          </div>
          <input
            type="date"
            value={filters.start_date}
            onChange={(e) => handleFilterChange('start_date', e.target.value)}
            className="bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
          />
          <span className="text-slate-400">a</span>
          <input
            type="date"
            value={filters.end_date}
            onChange={(e) => handleFilterChange('end_date', e.target.value)}
            className="bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
          />
          <button
            onClick={loadReportData}
            className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2"
          >
            <HiOutlineRefresh className="w-4 h-4" />
            Actualizar
          </button>
        </div>
      </div>
      
      {loading ? (
        <div className="p-8 text-center text-slate-400">Cargando reportes...</div>
      ) : profitMargins ? (
        <>
          {/* Stats financieros */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard
              icon={HiOutlineCash}
              title="Ingresos Totales"
              value={formatCurrency(profitMargins.totals?.total_revenue)}
              color="green"
            />
            <StatCard
              icon={HiOutlineShoppingCart}
              title="Productos Vendidos"
              value={formatNumber(profitMargins.totals?.total_quantity)}
              color="blue"
            />
            <StatCard
              icon={HiOutlineCube}
              title="Productos Únicos"
              value={formatNumber(profitMargins.totals?.total_products)}
              color="purple"
            />
            <StatCard
              icon={HiOutlineTrendingUp}
              title="Ticket Promedio"
              value={formatCurrency(
                profitMargins.totals?.total_revenue && profitMargins.totals?.total_quantity
                  ? profitMargins.totals.total_revenue / profitMargins.totals.total_quantity
                  : 0
              )}
              color="yellow"
            />
          </div>
          
          {/* Tabla de productos más rentables */}
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between">
              <h3 className="font-medium text-white flex items-center gap-2">
                <HiOutlineCurrencyDollar className="w-5 h-5 text-green-400" />
                Análisis de Ingresos por Producto
              </h3>
              <button
                onClick={() => exportToCSV(profitMargins.products || [], 'analisis_ingresos')}
                className="text-slate-400 hover:text-white flex items-center gap-2 text-sm"
              >
                <HiOutlineDownload className="w-4 h-4" />
                Exportar CSV
              </button>
            </div>
            
            {!profitMargins.products || profitMargins.products.length === 0 ? (
              <div className="p-8 text-center text-slate-400">No hay datos disponibles</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-900/50">
                    <tr>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">#</th>
                      <th className="text-left p-4 text-sm text-slate-400 font-medium">Producto</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Cantidad</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Precio Prom.</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">Ingresos</th>
                      <th className="text-right p-4 text-sm text-slate-400 font-medium">% del Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/50">
                    {profitMargins.products.slice(0, 15).map((product, idx) => {
                      const percentage = profitMargins.totals?.total_revenue > 0
                        ? ((product.total_revenue || 0) / profitMargins.totals.total_revenue) * 100
                        : 0;
                      return (
                        <tr key={product.product_id} className="hover:bg-slate-700/30 transition-colors">
                          <td className="p-4 text-slate-400">{idx + 1}</td>
                          <td className="p-4 text-white font-medium">{product.product_name}</td>
                          <td className="p-4 text-right text-slate-300">{formatNumber(product.total_quantity)}</td>
                          <td className="p-4 text-right text-slate-300">{formatCurrency(product.avg_price)}</td>
                          <td className="p-4 text-right text-green-400 font-medium">{formatCurrency(product.total_revenue)}</td>
                          <td className="p-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <div className="w-16 h-2 bg-slate-700 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-green-500 rounded-full"
                                  style={{ width: `${Math.min(percentage, 100)}%` }}
                                />
                              </div>
                              <span className="text-slate-300 text-sm w-12">{formatPercent(percentage)}</span>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="p-8 text-center text-slate-400">No hay datos financieros disponibles</div>
      )}
    </div>
  );
  
  // Tab: Insights de IA
  const renderInsights = () => (
    <div className="space-y-6">
      {loading ? (
        <div className="p-8 text-center text-slate-400">Cargando insights...</div>
      ) : (
        <>
          {/* Info de IA */}
          <div className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30 rounded-xl p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-purple-500/20">
                <HiOutlineChartPie className="w-8 h-8 text-purple-400" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-white">Análisis con Inteligencia Artificial</h3>
                <p className="text-slate-300 mt-1">
                  Rauli ERP utiliza análisis avanzado para generar insights sobre tu negocio.
                  Conecta con Ollama para obtener predicciones y recomendaciones personalizadas.
                </p>
              </div>
            </div>
          </div>
          
          {businessInsights ? (
            <>
              {/* Resumen */}
              {businessInsights.summary && (
                <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
                  <h3 className="font-medium text-white mb-4">Resumen del Negocio</h3>
                  <p className="text-slate-300">{businessInsights.summary}</p>
                </div>
              )}
              
              {/* Lista de insights */}
              {businessInsights.insights && businessInsights.insights.length > 0 && (
                <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
                  <h3 className="font-medium text-white mb-4">Recomendaciones</h3>
                  <div className="space-y-4">
                    {businessInsights.insights.map((insight, idx) => (
                      <div 
                        key={idx} 
                        className={`p-4 rounded-lg border ${
                          insight.type === 'warning' ? 'bg-yellow-500/10 border-yellow-500/30' :
                          insight.type === 'success' ? 'bg-green-500/10 border-green-500/30' :
                          insight.type === 'danger' ? 'bg-red-500/10 border-red-500/30' :
                          'bg-blue-500/10 border-blue-500/30'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <HiOutlineDocumentReport className={`w-5 h-5 mt-0.5 ${
                            insight.type === 'warning' ? 'text-yellow-400' :
                            insight.type === 'success' ? 'text-green-400' :
                            insight.type === 'danger' ? 'text-red-400' :
                            'text-blue-400'
                          }`} />
                          <p className="text-slate-300">{insight.message}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Predicciones */}
              {businessInsights.predictions && (
                <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
                  <h3 className="font-medium text-white mb-4">Predicciones</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.entries(businessInsights.predictions).map(([key, value]) => (
                      <div key={key} className="bg-slate-700/30 rounded-lg p-4">
                        <p className="text-sm text-slate-400 capitalize">{key.replace(/_/g, ' ')}</p>
                        <p className="text-xl font-bold text-white mt-1">
                          {typeof value === 'number' ? formatCurrency(value) : value}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-8 text-center">
              <HiOutlineChartPie className="w-16 h-16 mx-auto text-slate-600 mb-4" />
              <h3 className="text-lg font-medium text-white mb-2">Sin Datos de IA</h3>
              <p className="text-slate-400 max-w-md mx-auto">
                Configura la conexión con Ollama en Ajustes para obtener 
                análisis predictivo y recomendaciones basadas en IA.
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
  
  // ==================== RENDER PRINCIPAL ====================
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Reportes</h1>
        <p className="text-slate-400">Análisis y reportes del negocio</p>
      </div>
      
      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-700 pb-2 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-purple-600 text-white'
                : 'text-slate-400 hover:bg-slate-700/50 hover:text-white'
            }`}
          >
            <tab.icon className="w-5 h-5" />
            {tab.name}
          </button>
        ))}
      </div>
      
      {/* Tab Content */}
      {activeTab === 'sales' && renderSalesReports()}
      {activeTab === 'inventory' && renderInventoryReports()}
      {activeTab === 'employees' && renderEmployeeReports()}
      {activeTab === 'financial' && renderFinancialReports()}
      {activeTab === 'insights' && renderInsights()}
    </div>
  );
}
