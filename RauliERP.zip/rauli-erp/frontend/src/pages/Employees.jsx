/**
 * Rauli ERP - Employees/HR Management Page
 */

import { useState, useEffect } from 'react';
import { 
  HiOutlineUsers, HiOutlinePlus, HiOutlineRefresh, HiOutlineCash,
  HiOutlineCalendar, HiOutlineClock, HiOutlineChartBar, HiOutlineX,
  HiOutlineCheck, HiOutlinePencil, HiOutlineUserCircle
} from 'react-icons/hi';
import { employees } from '../services/api';

const TABS = [
  { id: 'dashboard', label: 'Dashboard', icon: HiOutlineChartBar },
  { id: 'employees', label: 'Empleados', icon: HiOutlineUsers },
  { id: 'schedules', label: 'Horarios', icon: HiOutlineCalendar },
  { id: 'commissions', label: 'Comisiones', icon: HiOutlineCash },
  { id: 'payroll', label: 'Nómina', icon: HiOutlineClock },
];

export default function Employees() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  const [dashboard, setDashboard] = useState(null);
  const [employeeList, setEmployeeList] = useState([]);
  const [shifts, setShifts] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [commissions, setCommissions] = useState([]);
  const [payrolls, setPayrolls] = useState([]);
  
  const [showEmployeeModal, setShowEmployeeModal] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState(null);
  
  const [scheduleFilter, setScheduleFilter] = useState({ start_date: getWeekStart(), end_date: getWeekEnd() });

  function getWeekStart() {
    const d = new Date();
    d.setDate(d.getDate() - d.getDay());
    return d.toISOString().split('T')[0];
  }
  
  function getWeekEnd() {
    const d = new Date();
    d.setDate(d.getDate() - d.getDay() + 6);
    return d.toISOString().split('T')[0];
  }

  useEffect(() => { loadData(); }, []);

  useEffect(() => {
    if (activeTab === 'employees') loadEmployees();
    if (activeTab === 'schedules') loadSchedules();
    if (activeTab === 'commissions') loadCommissions();
    if (activeTab === 'payroll') loadPayrolls();
  }, [activeTab, scheduleFilter]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [dashRes, shiftsRes] = await Promise.all([
        employees.dashboard(),
        employees.shifts()
      ]);
      setDashboard(dashRes.data.dashboard);
      setShifts(shiftsRes.data.shifts || []);
    } catch (err) {
      console.error('Error loading HR data:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadEmployees = async () => {
    try {
      const res = await employees.list({ active: 'all' });
      setEmployeeList(res.data.employees || []);
    } catch (err) { console.error('Error loading employees:', err); }
  };

  const loadSchedules = async () => {
    try {
      const res = await employees.schedules(scheduleFilter);
      setSchedules(res.data.schedules || []);
    } catch (err) { console.error('Error loading schedules:', err); }
  };

  const loadCommissions = async () => {
    try {
      const res = await employees.commissions({});
      setCommissions(res.data.commissions || []);
    } catch (err) { console.error('Error loading commissions:', err); }
  };

  const loadPayrolls = async () => {
    try {
      const res = await employees.payroll({});
      setPayrolls(res.data.payrolls || []);
    } catch (err) { console.error('Error loading payrolls:', err); }
  };

  const formatCurrency = (amount) => new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(amount || 0);
  const formatDate = (date) => date ? new Date(date).toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' }) : '-';

  const getStatusBadge = (status) => {
    const styles = {
      'pending': 'bg-yellow-500/20 text-yellow-400',
      'approved': 'bg-blue-500/20 text-blue-400',
      'paid': 'bg-green-500/20 text-green-400',
      'draft': 'bg-slate-500/20 text-slate-400',
      'scheduled': 'bg-blue-500/20 text-blue-400',
      'working': 'bg-green-500/20 text-green-400',
      'completed': 'bg-green-500/20 text-green-400',
    };
    return styles[status] || 'bg-slate-500/20 text-slate-400';
  };

  // ==================== TAB COMPONENTS ====================
  const DashboardTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Empleados Activos" value={dashboard?.active_employees || 0} icon={HiOutlineUsers} color="blue" />
        <StatCard title="Comisiones Pendientes" value={formatCurrency(dashboard?.pending_commissions?.total)} icon={HiOutlineCash} color="yellow" />
        <StatCard title="Turnos Hoy" value={dashboard?.today_schedules?.length || 0} icon={HiOutlineCalendar} color="green" />
        <StatCard title="Total Comisiones" value={dashboard?.pending_commissions?.count || 0} icon={HiOutlineChartBar} color="purple" />
      </div>

      {/* Today's Schedules */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
        <h3 className="font-semibold text-white mb-4">Turnos de Hoy</h3>
        <div className="grid gap-2">
          {(dashboard?.today_schedules || []).map(sch => (
            <div key={sch.id} className="flex justify-between items-center bg-slate-700/30 rounded-lg p-3">
              <div className="flex items-center gap-3">
                <HiOutlineUserCircle className="w-8 h-8 text-slate-400" />
                <div>
                  <span className="font-medium text-white">{sch.employee_name}</span>
                  <span className="text-slate-400 ml-2 text-sm">{sch.shift_name}</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-indigo-400 font-mono">{sch.start_time} - {sch.end_time}</span>
                {sch.actual_start && <span className="text-green-400 ml-2 text-sm">✓ Entrada: {sch.actual_start}</span>}
              </div>
            </div>
          ))}
          {(dashboard?.today_schedules || []).length === 0 && (
            <p className="text-slate-500 text-center py-4">No hay turnos programados para hoy</p>
          )}
        </div>
      </div>

      {/* Top Sellers */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
        <h3 className="font-semibold text-white mb-4">Top Vendedores del Mes</h3>
        <div className="space-y-2">
          {(dashboard?.top_sellers || []).map((seller, idx) => (
            <div key={seller.code} className="flex justify-between items-center py-2 border-b border-slate-700/50 last:border-0">
              <div className="flex items-center gap-3">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold ${idx === 0 ? 'bg-yellow-500 text-black' : idx === 1 ? 'bg-slate-400 text-black' : idx === 2 ? 'bg-amber-700 text-white' : 'bg-slate-700 text-slate-300'}`}>
                  {idx + 1}
                </span>
                <div>
                  <span className="font-medium text-white">{seller.name}</span>
                  <span className="text-slate-500 ml-2 text-sm">{seller.code}</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-green-400 font-medium">{formatCurrency(seller.total_sales)}</span>
                <span className="text-slate-500 ml-2 text-sm">{seller.sales_count} ventas</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const EmployeesTab = () => (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button onClick={() => { setEditingEmployee(null); setShowEmployeeModal(true); }}
          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors">
          <HiOutlinePlus className="w-5 h-5" />Nuevo Empleado
        </button>
      </div>

      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-700/50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Código</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Nombre</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Posición</th>
              <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">Salario</th>
              <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">Comisión %</th>
              <th className="px-4 py-3 text-center text-sm font-medium text-slate-300">Estado</th>
              <th className="px-4 py-3 text-center text-sm font-medium text-slate-300">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {employeeList.map(emp => (
              <tr key={emp.id} className="border-t border-slate-700/50 hover:bg-slate-700/30">
                <td className="px-4 py-3 text-indigo-400 font-mono">{emp.code}</td>
                <td className="px-4 py-3">
                  <div>
                    <span className="text-white font-medium">{emp.name}</span>
                    {emp.email && <span className="text-slate-500 block text-sm">{emp.email}</span>}
                  </div>
                </td>
                <td className="px-4 py-3 text-slate-300">{emp.position || '-'}</td>
                <td className="px-4 py-3 text-right text-white">{formatCurrency(emp.salary)}</td>
                <td className="px-4 py-3 text-right text-slate-300">{(emp.commission_rate * 100).toFixed(1)}%</td>
                <td className="px-4 py-3 text-center">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${emp.active ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                    {emp.active ? 'Activo' : 'Inactivo'}
                  </span>
                </td>
                <td className="px-4 py-3 text-center">
                  <button onClick={() => { setEditingEmployee(emp); setShowEmployeeModal(true); }}
                    className="text-slate-400 hover:text-white p-1"><HiOutlinePencil className="w-5 h-5" /></button>
                </td>
              </tr>
            ))}
            {employeeList.length === 0 && <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">No hay empleados registrados</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );

  const SchedulesTab = () => (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-4 items-center justify-between">
        <div className="flex gap-3 items-center">
          <input type="date" value={scheduleFilter.start_date} onChange={e => setScheduleFilter({ ...scheduleFilter, start_date: e.target.value })}
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white" />
          <span className="text-slate-500">a</span>
          <input type="date" value={scheduleFilter.end_date} onChange={e => setScheduleFilter({ ...scheduleFilter, end_date: e.target.value })}
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white" />
        </div>
        <button onClick={() => setShowScheduleModal(true)}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors">
          <HiOutlinePlus className="w-5 h-5" />Asignar Turno
        </button>
      </div>

      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-700/50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Fecha</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Empleado</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Turno</th>
              <th className="px-4 py-3 text-center text-sm font-medium text-slate-300">Horario</th>
              <th className="px-4 py-3 text-center text-sm font-medium text-slate-300">Entrada Real</th>
              <th className="px-4 py-3 text-center text-sm font-medium text-slate-300">Salida Real</th>
              <th className="px-4 py-3 text-center text-sm font-medium text-slate-300">Estado</th>
            </tr>
          </thead>
          <tbody>
            {schedules.map(sch => (
              <tr key={sch.id} className="border-t border-slate-700/50 hover:bg-slate-700/30">
                <td className="px-4 py-3 text-white">{formatDate(sch.date)}</td>
                <td className="px-4 py-3">
                  <span className="text-white">{sch.employee_name}</span>
                  <span className="text-slate-500 ml-2 text-sm">{sch.employee_code}</span>
                </td>
                <td className="px-4 py-3">
                  <span className="px-2 py-1 rounded text-sm" style={{ backgroundColor: sch.color + '30', color: sch.color }}>{sch.shift_name}</span>
                </td>
                <td className="px-4 py-3 text-center text-slate-300 font-mono">{sch.start_time} - {sch.end_time}</td>
                <td className="px-4 py-3 text-center text-green-400 font-mono">{sch.actual_start || '-'}</td>
                <td className="px-4 py-3 text-center text-green-400 font-mono">{sch.actual_end || '-'}</td>
                <td className="px-4 py-3 text-center">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(sch.status)}`}>{sch.status}</span>
                </td>
              </tr>
            ))}
            {schedules.length === 0 && <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">No hay horarios en este período</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );

  const CommissionsTab = () => (
    <div className="space-y-4">
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-700/50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Fecha</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Empleado</th>
              <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">Venta</th>
              <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">Tasa</th>
              <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">Comisión</th>
              <th className="px-4 py-3 text-center text-sm font-medium text-slate-300">Estado</th>
            </tr>
          </thead>
          <tbody>
            {commissions.map(com => (
              <tr key={com.id} className="border-t border-slate-700/50 hover:bg-slate-700/30">
                <td className="px-4 py-3 text-slate-300">{formatDate(com.created_at)}</td>
                <td className="px-4 py-3">
                  <span className="text-white">{com.employee_name}</span>
                  <span className="text-slate-500 ml-2 text-sm">{com.employee_code}</span>
                </td>
                <td className="px-4 py-3 text-right text-slate-300">{formatCurrency(com.sale_total)}</td>
                <td className="px-4 py-3 text-right text-slate-400">{(com.rate * 100).toFixed(1)}%</td>
                <td className="px-4 py-3 text-right text-green-400 font-medium">{formatCurrency(com.amount)}</td>
                <td className="px-4 py-3 text-center">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(com.status)}`}>{com.status}</span>
                </td>
              </tr>
            ))}
            {commissions.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-500">No hay comisiones registradas</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );

  const PayrollTab = () => (
    <div className="space-y-4">
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-700/50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Período</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-slate-300">Empleado</th>
              <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">Salario Base</th>
              <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">Comisiones</th>
              <th className="px-4 py-3 text-right text-sm font-medium text-slate-300">Total</th>
              <th className="px-4 py-3 text-center text-sm font-medium text-slate-300">Estado</th>
            </tr>
          </thead>
          <tbody>
            {payrolls.map(pay => (
              <tr key={pay.id} className="border-t border-slate-700/50 hover:bg-slate-700/30">
                <td className="px-4 py-3 text-slate-300">{formatDate(pay.period_start)} - {formatDate(pay.period_end)}</td>
                <td className="px-4 py-3">
                  <span className="text-white">{pay.employee_name}</span>
                  <span className="text-slate-500 ml-2 text-sm">{pay.employee_code}</span>
                </td>
                <td className="px-4 py-3 text-right text-slate-300">{formatCurrency(pay.base_salary)}</td>
                <td className="px-4 py-3 text-right text-indigo-400">{formatCurrency(pay.commissions)}</td>
                <td className="px-4 py-3 text-right text-green-400 font-bold">{formatCurrency(pay.total)}</td>
                <td className="px-4 py-3 text-center">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(pay.status)}`}>{pay.status}</span>
                </td>
              </tr>
            ))}
            {payrolls.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-500">No hay nóminas generadas</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );

  // ==================== MODALS ====================
  const EmployeeModal = () => {
    const [form, setForm] = useState(editingEmployee || { name: '', email: '', phone: '', position: '', department: '', salary: 0, commission_rate: 0.05 });
    const [submitting, setSubmitting] = useState(false);
    const handleSubmit = async (e) => {
      e.preventDefault();
      setSubmitting(true);
      try {
        if (editingEmployee) {
          await employees.update(editingEmployee.id, form);
        } else {
          await employees.create(form);
        }
        setShowEmployeeModal(false);
        loadEmployees();
      } catch (err) { alert('Error: ' + err.message); }
      finally { setSubmitting(false); }
    };
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-slate-800 border border-slate-700 rounded-xl w-full max-w-lg">
          <div className="flex justify-between items-center p-4 border-b border-slate-700">
            <h3 className="text-lg font-semibold text-white">{editingEmployee ? 'Editar Empleado' : 'Nuevo Empleado'}</h3>
            <button onClick={() => setShowEmployeeModal(false)} className="text-slate-400 hover:text-white"><HiOutlineX className="w-6 h-6" /></button>
          </div>
          <form onSubmit={handleSubmit} className="p-4 space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Nombre *</label>
              <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white" required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Email</label>
                <input type="email" value={form.email || ''} onChange={e => setForm({ ...form, email: e.target.value })} className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Teléfono</label>
                <input type="text" value={form.phone || ''} onChange={e => setForm({ ...form, phone: e.target.value })} className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Posición</label>
                <input type="text" value={form.position || ''} onChange={e => setForm({ ...form, position: e.target.value })} className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white" placeholder="Ej: Cajero, Panadero" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Departamento</label>
                <input type="text" value={form.department || ''} onChange={e => setForm({ ...form, department: e.target.value })} className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white" placeholder="Ej: Ventas, Producción" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Salario Mensual</label>
                <input type="number" value={form.salary || 0} onChange={e => setForm({ ...form, salary: parseFloat(e.target.value) || 0 })} className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white" min="0" step="100" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Tasa de Comisión</label>
                <div className="relative">
                  <input type="number" value={(form.commission_rate || 0) * 100} onChange={e => setForm({ ...form, commission_rate: (parseFloat(e.target.value) || 0) / 100 })}
                    className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white pr-8" min="0" max="100" step="0.5" />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">%</span>
                </div>
              </div>
            </div>
            <div className="flex gap-3 pt-2">
              <button type="button" onClick={() => setShowEmployeeModal(false)} className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2 rounded-lg">Cancelar</button>
              <button type="submit" disabled={submitting} className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-lg disabled:opacity-50">{submitting ? 'Guardando...' : 'Guardar'}</button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  const ScheduleModal = () => {
    const [form, setForm] = useState({ employee_id: '', shift_id: '', date: new Date().toISOString().split('T')[0] });
    const [submitting, setSubmitting] = useState(false);
    const handleSubmit = async (e) => {
      e.preventDefault();
      setSubmitting(true);
      try {
        await employees.assignShift(form);
        setShowScheduleModal(false);
        loadSchedules();
        loadData();
      } catch (err) { alert('Error: ' + err.message); }
      finally { setSubmitting(false); }
    };
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-slate-800 border border-slate-700 rounded-xl w-full max-w-md">
          <div className="flex justify-between items-center p-4 border-b border-slate-700">
            <h3 className="text-lg font-semibold text-white">Asignar Turno</h3>
            <button onClick={() => setShowScheduleModal(false)} className="text-slate-400 hover:text-white"><HiOutlineX className="w-6 h-6" /></button>
          </div>
          <form onSubmit={handleSubmit} className="p-4 space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Empleado *</label>
              <select value={form.employee_id} onChange={e => setForm({ ...form, employee_id: e.target.value })} className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white" required>
                <option value="">Seleccionar...</option>
                {employeeList.filter(e => e.active).map(emp => <option key={emp.id} value={emp.id}>{emp.name} ({emp.code})</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Turno *</label>
              <select value={form.shift_id} onChange={e => setForm({ ...form, shift_id: e.target.value })} className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white" required>
                <option value="">Seleccionar...</option>
                {shifts.map(sh => <option key={sh.id} value={sh.id}>{sh.name} ({sh.start_time} - {sh.end_time})</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Fecha *</label>
              <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white" required />
            </div>
            <div className="flex gap-3 pt-2">
              <button type="button" onClick={() => setShowScheduleModal(false)} className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2 rounded-lg">Cancelar</button>
              <button type="submit" disabled={submitting} className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg disabled:opacity-50">{submitting ? 'Guardando...' : 'Asignar'}</button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  // ==================== RENDER ====================
  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-500 border-t-transparent"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold text-white">Recursos Humanos</h1>
          <p className="text-slate-400">Gestión de empleados, horarios, comisiones y nómina</p>
        </div>
        <button onClick={loadData} className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
          <HiOutlineRefresh className="w-5 h-5" />Actualizar
        </button>
      </div>

      <div className="flex gap-1 bg-slate-800/50 p-1 rounded-lg overflow-x-auto">
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${activeTab === tab.id ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-700/50'}`}>
            <tab.icon className="w-5 h-5" />{tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'dashboard' && <DashboardTab />}
      {activeTab === 'employees' && <EmployeesTab />}
      {activeTab === 'schedules' && <SchedulesTab />}
      {activeTab === 'commissions' && <CommissionsTab />}
      {activeTab === 'payroll' && <PayrollTab />}

      {showEmployeeModal && <EmployeeModal />}
      {showScheduleModal && <ScheduleModal />}
    </div>
  );
}

function StatCard({ title, value, icon: Icon, color }) {
  const colorClasses = { blue: 'bg-blue-500/20 text-blue-400', green: 'bg-green-500/20 text-green-400', yellow: 'bg-yellow-500/20 text-yellow-400', purple: 'bg-purple-500/20 text-purple-400' };
  return (
    <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-slate-400 text-sm">{title}</span>
        <div className={`p-2 rounded-lg ${colorClasses[color]}`}><Icon className="w-5 h-5" /></div>
      </div>
      <p className="text-2xl font-bold text-white">{value}</p>
    </div>
  );
}
