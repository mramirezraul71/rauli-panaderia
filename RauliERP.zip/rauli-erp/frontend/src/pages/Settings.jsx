/**
 * Rauli ERP - Settings Page
 */

import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSync } from '../context/SyncContext';
import toast from 'react-hot-toast';
import {
  HiOutlineCog,
  HiOutlineDownload,
  HiOutlineTrash,
  HiOutlineRefresh,
  HiOutlineKey,
  HiOutlineDatabase,
} from 'react-icons/hi';

export default function Settings() {
  const { user, changePassword, isOnline } = useAuth();
  const { downloadOfflineData, clearLocalData, syncAll, pendingCount, lastSync } = useSync();
  const [passwords, setPasswords] = useState({ current: '', new: '', confirm: '' });
  const [saving, setSaving] = useState(false);

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    if (passwords.new !== passwords.confirm) {
      toast.error('Las contraseñas no coinciden');
      return;
    }
    if (passwords.new.length < 6) {
      toast.error('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    setSaving(true);
    const result = await changePassword(passwords.current, passwords.new);
    setSaving(false);

    if (result.success) {
      setPasswords({ current: '', new: '', confirm: '' });
    }
  };

  const handleDownload = async () => {
    await downloadOfflineData();
  };

  const handleClearData = async () => {
    if (confirm('¿Eliminar todos los datos locales? Los datos pendientes de sincronizar se perderán.')) {
      await clearLocalData();
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold text-white">Configuración</h1>
        <p className="text-slate-400">Preferencias y ajustes del sistema</p>
      </div>

      {/* User Info */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
        <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <HiOutlineCog className="w-5 h-5 text-indigo-400" />
          Información de Usuario
        </h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-slate-400">Nombre</p>
            <p className="text-white">{user?.name}</p>
          </div>
          <div>
            <p className="text-sm text-slate-400">Usuario</p>
            <p className="text-white">{user?.username}</p>
          </div>
          <div>
            <p className="text-sm text-slate-400">Rol</p>
            <p className="text-white capitalize">{user?.role}</p>
          </div>
          <div>
            <p className="text-sm text-slate-400">Estado</p>
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs ${
              isOnline ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
            }`}>
              {isOnline ? 'Online' : 'Offline'}
            </span>
          </div>
        </div>
      </div>

      {/* Change Password */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
        <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <HiOutlineKey className="w-5 h-5 text-indigo-400" />
          Cambiar Contraseña
        </h2>
        <form onSubmit={handlePasswordChange} className="space-y-4">
          <div>
            <label className="block text-sm text-slate-400 mb-1">Contraseña actual</label>
            <input
              type="password"
              value={passwords.current}
              onChange={(e) => setPasswords({...passwords, current: e.target.value})}
              className="w-full px-4 py-2.5 bg-slate-700/50 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-slate-400 mb-1">Nueva contraseña</label>
              <input
                type="password"
                value={passwords.new}
                onChange={(e) => setPasswords({...passwords, new: e.target.value})}
                className="w-full px-4 py-2.5 bg-slate-700/50 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-slate-400 mb-1">Confirmar</label>
              <input
                type="password"
                value={passwords.confirm}
                onChange={(e) => setPasswords({...passwords, confirm: e.target.value})}
                className="w-full px-4 py-2.5 bg-slate-700/50 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                required
              />
            </div>
          </div>
          <button
            type="submit"
            disabled={saving || !isOnline}
            className="px-6 py-2.5 bg-indigo-500 text-white rounded-xl hover:bg-indigo-600 transition-colors disabled:opacity-50"
          >
            {saving ? 'Guardando...' : 'Cambiar Contraseña'}
          </button>
        </form>
      </div>

      {/* Data Management */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
        <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <HiOutlineDatabase className="w-5 h-5 text-indigo-400" />
          Datos Offline
        </h2>
        
        <div className="space-y-4">
          {/* Sync Info */}
          <div className="p-4 bg-slate-700/30 rounded-xl">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-slate-400">Pendientes de sincronizar</p>
                <p className="text-white font-medium">{pendingCount} elementos</p>
              </div>
              <div>
                <p className="text-slate-400">Última sincronización</p>
                <p className="text-white font-medium">
                  {lastSync ? new Date(lastSync).toLocaleString() : 'Nunca'}
                </p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-wrap gap-3">
            <button
              onClick={syncAll}
              disabled={!isOnline || pendingCount === 0}
              className="flex items-center gap-2 px-4 py-2.5 bg-indigo-500 text-white rounded-xl hover:bg-indigo-600 transition-colors disabled:opacity-50"
            >
              <HiOutlineRefresh className="w-5 h-5" />
              Sincronizar Ahora
            </button>
            <button
              onClick={handleDownload}
              disabled={!isOnline}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-700 text-white rounded-xl hover:bg-slate-600 transition-colors disabled:opacity-50"
            >
              <HiOutlineDownload className="w-5 h-5" />
              Descargar Datos
            </button>
            <button
              onClick={handleClearData}
              className="flex items-center gap-2 px-4 py-2.5 bg-red-500/20 text-red-400 rounded-xl hover:bg-red-500/30 transition-colors"
            >
              <HiOutlineTrash className="w-5 h-5" />
              Limpiar Cache
            </button>
          </div>
        </div>
      </div>

      {/* Version Info */}
      <div className="text-center text-slate-500 text-sm">
        Rauli ERP v1.0.0 - Sistema Offline-First para Panaderías
      </div>
    </div>
  );
}
