/**
 * Rauli ERP - Dashboard Page
 */

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSync } from '../context/SyncContext';
import {
  HiOutlineCurrencyDollar,
  HiOutlineShoppingCart,
  HiOutlineCube,
  HiOutlineExclamationCircle,
  HiOutlineTrendingUp,
  HiOutlineTrendingDown,
  HiOutlineArrowRight,
  HiOutlineRefresh,
} from 'react-icons/hi';

export default function Dashboard() {
  const { authFetch, user, isOnline } = useAuth();
  const { pendingCount, syncStatus, syncAll } = useSync();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    if (!isOnline) {
      setLoading(false);
      return;
    }

    try {
      const [salesRes, inventoryRes] = await Promise.all([
        authFetch('/sales/today'),
        authFetch('/inventory/summary'),
      ]);

      const salesData = salesRes.ok ? await salesRes.json() : null;
      const inventoryData = inventoryRes.ok ? await inventoryRes.json() : null;

      setStats({
        sales: salesData?.summary || {},
        inventory: inventoryData?.summary || {},
      });
    } catch (err) {
      console.error('Error loading dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('es-DO', {
      style: 'currency',
      currency: 'DOP',
    }).format(value || 0);
  };

  const StatCard = ({ title, value, icon: Icon, trend, trendValue, color, link }) => (
    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6 hover:border-slate-600/50 transition-colors">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-slate-400 mb-1">{title}</p>
          <p className="text-2xl font-bold text-white">{value}</p>
          {trend && (
            <div className={`flex items-center gap-1 mt-2 text-sm ${trend === 'up' ? 'text-emerald-400' : 'text-red-400'}`}>
              {trend === 'up' ? <HiOutlineTrendingUp className="w-4 h-4" /> : <HiOutlineTrendingDown className="w-4 h-4" />}
              <span>{trendValue}</span>
            </div>
          )}
        </div>
        <div className={`p-3 rounded-xl ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
      {link && (
        <Link 
          to={link} 
          className="flex items-center gap-1 mt-4 text-sm text-indigo-400 hover:text-indigo-300 transition-colors"
        >
          Ver detalles <HiOutlineArrowRight className="w-4 h-4" />
        </Link>
      )}
    </div>
  );

  const QuickAction = ({ title, description, icon: Icon, to, color }) => (
    <Link
      to={to}
      className="flex items-center gap-4 p-4 bg-slate-800/50 border border-slate-700/50 rounded-xl hover:border-indigo-500/50 hover:bg-slate-800 transition-all group"
    >
      <div className={`p-3 rounded-xl ${color} group-hover:scale-110 transition-transform`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <div>
        <h3 className="font-medium text-white">{title}</h3>
        <p className="text-sm text-slate-400">{description}</p>
      </div>
      <HiOutlineArrowRight className="w-5 h-5 text-slate-400 ml-auto group-hover:text-indigo-400 group-hover:translate-x-1 transition-all" />
    </Link>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">¡Bienvenido, {user?.name}!</h1>
          <p className="text-slate-400">Resumen de tu negocio hoy</p>
        </div>
        <button
          onClick={loadDashboard}
          disabled={!isOnline}
          className="flex items-center gap-2 px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-slate-300 hover:text-white hover:border-slate-600 transition-colors disabled:opacity-50"
        >
          <HiOutlineRefresh className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
          Actualizar
        </button>
      </div>

      {/* Offline warning */}
      {!isOnline && (
        <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
          <div className="flex items-center gap-3">
            <HiOutlineExclamationCircle className="w-6 h-6 text-amber-400" />
            <div>
              <p className="font-medium text-amber-400">Modo sin conexión</p>
              <p className="text-sm text-amber-400/80">Los datos mostrados pueden no estar actualizados</p>
            </div>
          </div>
        </div>
      )}

      {/* Pending sync */}
      {pendingCount > 0 && (
        <div className="p-4 bg-indigo-500/10 border border-indigo-500/20 rounded-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-500/20 rounded-lg">
                <HiOutlineRefresh className="w-5 h-5 text-indigo-400" />
              </div>
              <div>
                <p className="font-medium text-indigo-400">{pendingCount} elementos pendientes de sincronizar</p>
                <p className="text-sm text-indigo-400/80">Los datos se sincronizarán cuando haya conexión</p>
              </div>
            </div>
            <button
              onClick={syncAll}
              disabled={!isOnline || syncStatus === 'syncing'}
              className="px-4 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition-colors disabled:opacity-50"
            >
              {syncStatus === 'syncing' ? 'Sincronizando...' : 'Sincronizar'}
            </button>
          </div>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Ventas del Día"
          value={formatCurrency(stats?.sales?.total_sales)}
          icon={HiOutlineCurrencyDollar}
          color="bg-gradient-to-br from-emerald-500 to-teal-600"
          trend="up"
          trendValue="+12% vs ayer"
          link="/sales"
        />
        <StatCard
          title="Transacciones"
          value={stats?.sales?.transaction_count || 0}
          icon={HiOutlineShoppingCart}
          color="bg-gradient-to-br from-blue-500 to-cyan-600"
          link="/pos"
        />
        <StatCard
          title="Productos"
          value={stats?.inventory?.total_products || 0}
          icon={HiOutlineCube}
          color="bg-gradient-to-br from-purple-500 to-pink-600"
          link="/products"
        />
        <StatCard
          title="Stock Bajo"
          value={stats?.inventory?.low_stock_count || 0}
          icon={HiOutlineExclamationCircle}
          color={stats?.inventory?.low_stock_count > 0 ? "bg-gradient-to-br from-red-500 to-orange-600" : "bg-gradient-to-br from-slate-500 to-slate-600"}
          link="/inventory"
        />
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-4">Acciones Rápidas</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <QuickAction
            title="Nueva Venta"
            description="Iniciar una transacción en el POS"
            icon={HiOutlineShoppingCart}
            to="/pos"
            color="bg-gradient-to-br from-emerald-500 to-teal-600"
          />
          <QuickAction
            title="Agregar Producto"
            description="Registrar un nuevo producto"
            icon={HiOutlineCube}
            to="/products"
            color="bg-gradient-to-br from-blue-500 to-cyan-600"
          />
          <QuickAction
            title="Ver Reportes"
            description="Analizar el rendimiento"
            icon={HiOutlineTrendingUp}
            to="/reports"
            color="bg-gradient-to-br from-purple-500 to-pink-600"
          />
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Products */}
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Productos Más Vendidos Hoy</h3>
          {stats?.sales?.top_products?.length > 0 ? (
            <div className="space-y-3">
              {stats.sales.top_products.slice(0, 5).map((product, index) => (
                <div key={product.id || index} className="flex items-center justify-between py-2 border-b border-slate-700/50 last:border-0">
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 flex items-center justify-center bg-indigo-500/20 text-indigo-400 text-xs font-medium rounded-full">
                      {index + 1}
                    </span>
                    <span className="text-slate-300">{product.name}</span>
                  </div>
                  <span className="text-white font-medium">{product.quantity} uds</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-slate-400 text-center py-8">No hay ventas registradas hoy</p>
          )}
        </div>

        {/* Low Stock Alert */}
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Alertas de Stock</h3>
          {stats?.inventory?.low_stock_count > 0 ? (
            <div className="space-y-3">
              <p className="text-amber-400 text-sm">
                ⚠️ {stats.inventory.low_stock_count} productos con stock bajo
              </p>
              <Link
                to="/inventory"
                className="inline-flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors"
              >
                Ver inventario completo <HiOutlineArrowRight className="w-4 h-4" />
              </Link>
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="w-12 h-12 mx-auto mb-3 bg-emerald-500/20 rounded-full flex items-center justify-center">
                <HiOutlineCube className="w-6 h-6 text-emerald-400" />
              </div>
              <p className="text-emerald-400">Todo el inventario está bien abastecido</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
