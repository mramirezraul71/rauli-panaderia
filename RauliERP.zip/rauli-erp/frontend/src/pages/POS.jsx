/**
 * Rauli ERP - POS (Punto de Venta)
 */

import { useState, useEffect, useMemo, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSync } from '../context/SyncContext';
import localDB from '../db/localDB';
import toast from 'react-hot-toast';
import {
  HiOutlineSearch,
  HiOutlinePlus,
  HiOutlineMinus,
  HiOutlineTrash,
  HiOutlineCash,
  HiOutlineCreditCard,
  HiOutlineQrcode,
  HiOutlineX,
  HiOutlineCalculator,
  HiOutlineTag,
  HiOutlineClipboardList,
} from 'react-icons/hi';

export default function POS() {
  const { authFetch, user, isOnline } = useAuth();
  const { addToSyncQueue } = useSync();
  
  // State
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [cart, setCart] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(true);
  const [showPayment, setShowPayment] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [amountReceived, setAmountReceived] = useState('');
  const [processing, setProcessing] = useState(false);

  // Load products and categories
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      if (isOnline) {
        const [productsRes, categoriesRes] = await Promise.all([
          authFetch('/products?active=1'),
          authFetch('/products/categories'),
        ]);

        if (productsRes.ok) {
          const { products: prods } = await productsRes.json();
          setProducts(prods);
          await localDB.bulkSaveProducts(prods);
        }

        if (categoriesRes.ok) {
          const { categories: cats } = await categoriesRes.json();
          setCategories(cats);
          await localDB.bulkSaveCategories(cats);
        }
      } else {
        // Load from local DB
        const localProducts = await localDB.getProducts();
        const localCategories = await localDB.getCategories();
        setProducts(localProducts);
        setCategories(localCategories);
      }
    } catch (err) {
      console.error('Error loading data:', err);
      // Fallback to local
      const localProducts = await localDB.getProducts();
      const localCategories = await localDB.getCategories();
      setProducts(localProducts);
      setCategories(localCategories);
    } finally {
      setLoading(false);
    }
  };

  // Filtered products
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           product.barcode?.includes(searchTerm);
      const matchesCategory = selectedCategory === 'all' || product.category_id === selectedCategory;
      return matchesSearch && matchesCategory && product.stock > 0;
    });
  }, [products, searchTerm, selectedCategory]);

  // Cart calculations
  const cartTotals = useMemo(() => {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.18; // 18% ITBIS
    const total = subtotal + tax;
    return { subtotal, tax, total };
  }, [cart]);

  // Cart functions
  const addToCart = useCallback((product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) {
          toast.error('Stock insuficiente');
          return prev;
        }
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  }, []);

  const updateQuantity = useCallback((productId, delta) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.id === productId) {
          const newQty = item.quantity + delta;
          if (newQty <= 0) return null;
          if (newQty > item.stock) {
            toast.error('Stock insuficiente');
            return item;
          }
          return { ...item, quantity: newQty };
        }
        return item;
      }).filter(Boolean);
    });
  }, []);

  const removeFromCart = useCallback((productId) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
    setShowPayment(false);
    setAmountReceived('');
  }, []);

  // Process sale
  const processSale = async () => {
    if (cart.length === 0) {
      toast.error('El carrito está vacío');
      return;
    }

    setProcessing(true);

    try {
      const saleData = {
        items: cart.map(item => ({
          product_id: item.id,
          quantity: item.quantity,
          unit_price: item.price,
        })),
        payment_method: paymentMethod,
        subtotal: cartTotals.subtotal,
        tax: cartTotals.tax,
        total: cartTotals.total,
        amount_received: paymentMethod === 'cash' ? parseFloat(amountReceived) : cartTotals.total,
      };

      if (isOnline) {
        const response = await authFetch('/sales', {
          method: 'POST',
          body: JSON.stringify(saleData),
        });

        if (response.ok) {
          const { sale } = await response.json();
          toast.success(`Venta #${sale.sale_number} completada`);
          clearCart();
          loadData(); // Refresh products
        } else {
          const error = await response.json();
          throw new Error(error.message || 'Error al procesar venta');
        }
      } else {
        // Save locally and queue for sync
        const localId = `local_${Date.now()}`;
        await localDB.saveSale({ ...saleData, local_id: localId, status: 'pending_sync' });
        await addToSyncQueue('sale', 'create', { ...saleData, local_id: localId });
        
        // Update local stock
        for (const item of cart) {
          await localDB.updateProductStock(item.id, -item.quantity);
        }

        toast.success('Venta guardada (se sincronizará cuando haya conexión)');
        clearCart();
        loadData();
      }
    } catch (err) {
      toast.error(err.message);
    } finally {
      setProcessing(false);
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('es-DO', {
      style: 'currency',
      currency: 'DOP',
    }).format(value);
  };

  const change = paymentMethod === 'cash' && amountReceived 
    ? parseFloat(amountReceived) - cartTotals.total 
    : 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-8rem)]">
        <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-4">
      {/* Products Section */}
      <div className="flex-1 flex flex-col bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
        {/* Search and filters */}
        <div className="p-4 border-b border-slate-700/50 space-y-3">
          <div className="relative">
            <HiOutlineSearch className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar producto o código de barras..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-700/50 border border-slate-600 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
            />
          </div>
          
          {/* Categories */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                selectedCategory === 'all'
                  ? 'bg-indigo-500 text-white'
                  : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Todos
            </button>
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-indigo-500 text-white'
                    : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
            {filteredProducts.map(product => (
              <button
                key={product.id}
                onClick={() => addToCart(product)}
                className="p-4 bg-slate-700/30 hover:bg-slate-700/50 border border-slate-600/50 hover:border-indigo-500/50 rounded-xl text-left transition-all group"
              >
                <div className="w-full aspect-square bg-slate-600/50 rounded-lg mb-3 flex items-center justify-center">
                  {product.image_url ? (
                    <img src={product.image_url} alt={product.name} className="w-full h-full object-cover rounded-lg" />
                  ) : (
                    <HiOutlineTag className="w-8 h-8 text-slate-400" />
                  )}
                </div>
                <h3 className="font-medium text-white text-sm truncate">{product.name}</h3>
                <p className="text-indigo-400 font-semibold">{formatCurrency(product.price)}</p>
                <p className="text-xs text-slate-400">Stock: {product.stock}</p>
              </button>
            ))}
          </div>
          
          {filteredProducts.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-slate-400">
              <HiOutlineClipboardList className="w-12 h-12 mb-3" />
              <p>No se encontraron productos</p>
            </div>
          )}
        </div>
      </div>

      {/* Cart Section */}
      <div className="w-96 flex flex-col bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden">
        {/* Cart Header */}
        <div className="p-4 border-b border-slate-700/50 flex items-center justify-between">
          <h2 className="font-semibold text-white">Carrito</h2>
          {cart.length > 0 && (
            <button
              onClick={clearCart}
              className="text-sm text-red-400 hover:text-red-300 transition-colors"
            >
              Limpiar
            </button>
          )}
        </div>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-slate-400">
              <HiOutlineCalculator className="w-12 h-12 mb-3" />
              <p>El carrito está vacío</p>
              <p className="text-sm">Selecciona productos para agregar</p>
            </div>
          ) : (
            cart.map(item => (
              <div key={item.id} className="flex items-center gap-3 p-3 bg-slate-700/30 rounded-xl">
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-white text-sm truncate">{item.name}</h4>
                  <p className="text-sm text-indigo-400">{formatCurrency(item.price)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => updateQuantity(item.id, -1)}
                    className="p-1.5 bg-slate-600 hover:bg-slate-500 rounded-lg transition-colors"
                  >
                    <HiOutlineMinus className="w-4 h-4 text-white" />
                  </button>
                  <span className="w-8 text-center text-white font-medium">{item.quantity}</span>
                  <button
                    onClick={() => updateQuantity(item.id, 1)}
                    className="p-1.5 bg-slate-600 hover:bg-slate-500 rounded-lg transition-colors"
                  >
                    <HiOutlinePlus className="w-4 h-4 text-white" />
                  </button>
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="p-1.5 bg-red-500/20 hover:bg-red-500/30 rounded-lg transition-colors ml-2"
                  >
                    <HiOutlineTrash className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Cart Totals */}
        <div className="p-4 border-t border-slate-700/50 space-y-3">
          <div className="flex justify-between text-slate-400">
            <span>Subtotal</span>
            <span>{formatCurrency(cartTotals.subtotal)}</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>ITBIS (18%)</span>
            <span>{formatCurrency(cartTotals.tax)}</span>
          </div>
          <div className="flex justify-between text-xl font-bold text-white pt-2 border-t border-slate-700">
            <span>Total</span>
            <span>{formatCurrency(cartTotals.total)}</span>
          </div>
        </div>

        {/* Payment Button */}
        <div className="p-4 border-t border-slate-700/50">
          <button
            onClick={() => setShowPayment(true)}
            disabled={cart.length === 0}
            className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-semibold rounded-xl shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            Cobrar {formatCurrency(cartTotals.total)}
          </button>
        </div>
      </div>

      {/* Payment Modal */}
      {showPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-slate-800 border border-slate-700 rounded-2xl w-full max-w-md m-4 overflow-hidden">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-white">Método de Pago</h3>
              <button
                onClick={() => setShowPayment(false)}
                className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
              >
                <HiOutlineX className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Payment Methods */}
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: 'cash', label: 'Efectivo', icon: HiOutlineCash },
                  { id: 'card', label: 'Tarjeta', icon: HiOutlineCreditCard },
                  { id: 'transfer', label: 'Transfer.', icon: HiOutlineQrcode },
                ].map(method => (
                  <button
                    key={method.id}
                    onClick={() => setPaymentMethod(method.id)}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      paymentMethod === method.id
                        ? 'border-indigo-500 bg-indigo-500/20'
                        : 'border-slate-600 hover:border-slate-500'
                    }`}
                  >
                    <method.icon className={`w-8 h-8 mx-auto mb-2 ${
                      paymentMethod === method.id ? 'text-indigo-400' : 'text-slate-400'
                    }`} />
                    <span className={`text-sm ${
                      paymentMethod === method.id ? 'text-indigo-400' : 'text-slate-300'
                    }`}>{method.label}</span>
                  </button>
                ))}
              </div>

              {/* Amount Received (for cash) */}
              {paymentMethod === 'cash' && (
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Monto Recibido
                  </label>
                  <input
                    type="number"
                    value={amountReceived}
                    onChange={(e) => setAmountReceived(e.target.value)}
                    placeholder="0.00"
                    className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-xl text-white text-xl text-center focus:outline-none focus:border-indigo-500"
                  />
                  {change > 0 && (
                    <div className="mt-3 p-3 bg-emerald-500/20 rounded-lg text-center">
                      <span className="text-emerald-400">Cambio: </span>
                      <span className="text-white font-bold">{formatCurrency(change)}</span>
                    </div>
                  )}
                </div>
              )}

              {/* Total */}
              <div className="p-4 bg-slate-700/30 rounded-xl text-center">
                <p className="text-slate-400 mb-1">Total a Pagar</p>
                <p className="text-3xl font-bold text-white">{formatCurrency(cartTotals.total)}</p>
              </div>

              {/* Confirm Button */}
              <button
                onClick={processSale}
                disabled={processing || (paymentMethod === 'cash' && parseFloat(amountReceived || 0) < cartTotals.total)}
                className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-semibold rounded-xl shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
              >
                {processing ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Procesando...
                  </>
                ) : (
                  'Confirmar Pago'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
