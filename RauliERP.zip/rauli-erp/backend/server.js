/**
 * Rauli ERP - Backend Server
 * Sistema de Gestión Integral para Panadería
 * Arquitectura Offline-First
 */

import express from 'express';
import cors from 'cors';
import { config } from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

// Importar rutas
import authRoutes from './routes/auth.js';
import productsRoutes from './routes/products.js';
import salesRoutes from './routes/sales.js';
import inventoryRoutes from './routes/inventory.js';
import accountingRoutes from './routes/accounting.js';
import employeesRoutes from './routes/employees.js';
import syncRoutes from './routes/sync.js';
import reportsRoutes from './routes/reports.js';
import predictionsRoutes from './routes/predictions.js';

// Configuración
config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors({
  origin: ['http://localhost:5173', 'http://localhost:4173'],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Logger middleware
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.path}`);
  next();
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    name: 'Rauli ERP API'
  });
});

// Rutas API
app.use('/api/auth', authRoutes);
app.use('/api/products', productsRoutes);
app.use('/api/sales', salesRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/accounting', accountingRoutes);
app.use('/api/employees', employeesRoutes);
app.use('/api/sync', syncRoutes);
app.use('/api/reports', reportsRoutes);
app.use('/api/predictions', predictionsRoutes);

// Manejo de errores global
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: true,
    message: err.message || 'Error interno del servidor',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: true, message: 'Ruta no encontrada' });
});

// Iniciar servidor
app.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🥖 RAULI ERP - Backend Server                          ║
║   ─────────────────────────────────────────────────────   ║
║   Sistema de Gestión Integral para Panadería             ║
║                                                           ║
║   ✓ Servidor iniciado en puerto ${PORT}                    ║
║   ✓ API disponible en http://localhost:${PORT}/api         ║
║   ✓ Health check: http://localhost:${PORT}/api/health      ║
║                                                           ║
║   Para acceso desde dispositivos móviles:                ║
║   Usar IP local de este equipo (ej: 192.168.1.x:${PORT})   ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
  `);
});

export default app;
