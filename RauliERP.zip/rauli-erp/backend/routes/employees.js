/**
 * Rauli ERP - Employees Routes (RRHH)
 */

import { Router } from 'express';
import { v4 as uuidv4 } from 'uuid';
import db from '../database/connection.js';
import { authMiddleware, requireRole } from './auth.js';

const router = Router();

// ==================== EMPLEADOS ====================

// GET /api/employees - Listar empleados
router.get('/', authMiddleware, (req, res) => {
  try {
    const { active = '1', department, position } = req.query;
    
    let sql = `
      SELECT e.*, u.username
      FROM employees e
      LEFT JOIN users u ON e.user_id = u.id
      WHERE 1=1
    `;
    const params = [];
    
    if (active !== 'all') {
      sql += ' AND e.active = ?';
      params.push(parseInt(active));
    }
    
    if (department) {
      sql += ' AND e.department = ?';
      params.push(department);
    }
    
    if (position) {
      sql += ' AND e.position = ?';
      params.push(position);
    }
    
    sql += ' ORDER BY e.name';
    
    const employees = db.prepare(sql).all(...params);
    res.json({ success: true, employees });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al listar empleados' });
  }
});

// GET /api/employees/:id
router.get('/:id', authMiddleware, (req, res) => {
  try {
    const employee = db.prepare(`
      SELECT e.*, u.username
      FROM employees e
      LEFT JOIN users u ON e.user_id = u.id
      WHERE e.id = ?
    `).get(req.params.id);
    
    if (!employee) {
      return res.status(404).json({ error: true, message: 'Empleado no encontrado' });
    }
    
    // Estadísticas del empleado
    const stats = db.prepare(`
      SELECT 
        COUNT(s.id) as total_sales,
        COALESCE(SUM(s.total), 0) as total_amount,
        COALESCE(SUM(c.amount), 0) as total_commissions
      FROM employees e
      LEFT JOIN sales s ON e.id = s.employee_id AND s.status = 'completed'
      LEFT JOIN commissions c ON e.id = c.employee_id AND c.status != 'cancelled'
      WHERE e.id = ?
    `).get(req.params.id);
    
    employee.stats = stats;
    res.json({ success: true, employee });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al obtener empleado' });
  }
});

// POST /api/employees
router.post('/', authMiddleware, requireRole('admin', 'gerente'), (req, res) => {
  try {
    const { name, email, phone, position, department, hire_date, salary, commission_rate, schedule_type, user_id } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: true, message: 'Nombre es requerido' });
    }
    
    const id = uuidv4();
    
    // Generar código de empleado
    const lastCode = db.prepare("SELECT code FROM employees WHERE code LIKE 'EMP%' ORDER BY code DESC LIMIT 1").get();
    const nextNum = lastCode ? parseInt(lastCode.code.replace('EMP', '')) + 1 : 1;
    const code = `EMP${String(nextNum).padStart(3, '0')}`;
    
    db.prepare(`
      INSERT INTO employees (id, code, name, email, phone, position, department, hire_date, salary, commission_rate, schedule_type, user_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, code, name, email, phone, position, department, hire_date, salary || 0, commission_rate || 0, schedule_type || 'fixed', user_id);
    
    const employee = db.prepare('SELECT * FROM employees WHERE id = ?').get(id);
    res.status(201).json({ success: true, employee });
  } catch (err) {
    console.error('Error creating employee:', err);
    res.status(500).json({ error: true, message: 'Error al crear empleado' });
  }
});

// PUT /api/employees/:id
router.put('/:id', authMiddleware, requireRole('admin', 'gerente'), (req, res) => {
  try {
    const { name, email, phone, position, department, hire_date, salary, commission_rate, schedule_type, active } = req.body;
    
    db.prepare(`
      UPDATE employees SET
        name = COALESCE(?, name),
        email = COALESCE(?, email),
        phone = COALESCE(?, phone),
        position = COALESCE(?, position),
        department = COALESCE(?, department),
        hire_date = COALESCE(?, hire_date),
        salary = COALESCE(?, salary),
        commission_rate = COALESCE(?, commission_rate),
        schedule_type = COALESCE(?, schedule_type),
        active = COALESCE(?, active),
        updated_at = datetime('now')
      WHERE id = ?
    `).run(name, email, phone, position, department, hire_date, salary, commission_rate, schedule_type, active, req.params.id);
    
    const employee = db.prepare('SELECT * FROM employees WHERE id = ?').get(req.params.id);
    res.json({ success: true, employee });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al actualizar empleado' });
  }
});

// ==================== TURNOS ====================

// GET /api/employees/shifts/list - Listar turnos disponibles
router.get('/shifts/list', authMiddleware, (req, res) => {
  try {
    const shifts = db.prepare('SELECT * FROM shifts WHERE active = 1 ORDER BY start_time').all();
    res.json({ success: true, shifts });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al listar turnos' });
  }
});

// POST /api/employees/shifts - Crear turno
router.post('/shifts', authMiddleware, requireRole('admin', 'gerente'), (req, res) => {
  try {
    const { name, start_time, end_time, break_minutes, days_of_week, color } = req.body;
    
    if (!name || !start_time || !end_time) {
      return res.status(400).json({ error: true, message: 'Datos incompletos' });
    }
    
    const id = uuidv4();
    db.prepare(`
      INSERT INTO shifts (id, name, start_time, end_time, break_minutes, days_of_week, color)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(id, name, start_time, end_time, break_minutes || 0, days_of_week, color || '#6366f1');
    
    const shift = db.prepare('SELECT * FROM shifts WHERE id = ?').get(id);
    res.status(201).json({ success: true, shift });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al crear turno' });
  }
});

// ==================== HORARIOS ====================

// GET /api/employees/schedules - Horarios programados
router.get('/schedules', authMiddleware, (req, res) => {
  try {
    const { employee_id, start_date, end_date } = req.query;
    
    let sql = `
      SELECT es.*, e.name as employee_name, e.code as employee_code, s.name as shift_name, s.start_time, s.end_time, s.color
      FROM employee_schedules es
      JOIN employees e ON es.employee_id = e.id
      JOIN shifts s ON es.shift_id = s.id
      WHERE 1=1
    `;
    const params = [];
    
    if (employee_id) {
      sql += ' AND es.employee_id = ?';
      params.push(employee_id);
    }
    
    if (start_date) {
      sql += ' AND es.date >= ?';
      params.push(start_date);
    }
    
    if (end_date) {
      sql += ' AND es.date <= ?';
      params.push(end_date);
    }
    
    sql += ' ORDER BY es.date, s.start_time';
    
    const schedules = db.prepare(sql).all(...params);
    res.json({ success: true, schedules });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al obtener horarios' });
  }
});

// POST /api/employees/schedules - Asignar turno
router.post('/schedules', authMiddleware, requireRole('admin', 'gerente'), (req, res) => {
  try {
    const { employee_id, shift_id, date, notes } = req.body;
    
    if (!employee_id || !shift_id || !date) {
      return res.status(400).json({ error: true, message: 'Datos incompletos' });
    }
    
    // Verificar que no existe asignación para ese día
    const existing = db.prepare(`
      SELECT id FROM employee_schedules WHERE employee_id = ? AND date = ?
    `).get(employee_id, date);
    
    if (existing) {
      return res.status(400).json({ error: true, message: 'Ya existe una asignación para ese día' });
    }
    
    const id = uuidv4();
    db.prepare(`
      INSERT INTO employee_schedules (id, employee_id, shift_id, date, notes)
      VALUES (?, ?, ?, ?, ?)
    `).run(id, employee_id, shift_id, date, notes);
    
    const schedule = db.prepare(`
      SELECT es.*, e.name as employee_name, s.name as shift_name
      FROM employee_schedules es
      JOIN employees e ON es.employee_id = e.id
      JOIN shifts s ON es.shift_id = s.id
      WHERE es.id = ?
    `).get(id);
    
    res.status(201).json({ success: true, schedule });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al asignar turno' });
  }
});

// POST /api/employees/schedules/bulk - Asignación masiva de turnos rotativos
router.post('/schedules/bulk', authMiddleware, requireRole('admin', 'gerente'), (req, res) => {
  try {
    const { assignments } = req.body;
    // assignments: [{ employee_id, shift_id, dates: ['2024-01-15', '2024-01-16', ...] }]
    
    const results = { created: 0, skipped: 0 };
    
    const checkExisting = db.prepare('SELECT id FROM employee_schedules WHERE employee_id = ? AND date = ?');
    const insertSchedule = db.prepare(`
      INSERT INTO employee_schedules (id, employee_id, shift_id, date)
      VALUES (?, ?, ?, ?)
    `);
    
    const transaction = db.transaction(() => {
      for (const assignment of assignments) {
        for (const date of assignment.dates) {
          const existing = checkExisting.get(assignment.employee_id, date);
          if (!existing) {
            insertSchedule.run(uuidv4(), assignment.employee_id, assignment.shift_id, date);
            results.created++;
          } else {
            results.skipped++;
          }
        }
      }
    });
    
    transaction();
    res.json({ success: true, results });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error en asignación masiva' });
  }
});

// PUT /api/employees/schedules/:id/check-in - Marcar entrada
router.put('/schedules/:id/check-in', authMiddleware, (req, res) => {
  try {
    const now = new Date().toTimeString().split(' ')[0];
    
    db.prepare(`
      UPDATE employee_schedules SET
        actual_start = ?,
        status = 'working'
      WHERE id = ?
    `).run(now, req.params.id);
    
    const schedule = db.prepare('SELECT * FROM employee_schedules WHERE id = ?').get(req.params.id);
    res.json({ success: true, schedule });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al registrar entrada' });
  }
});

// PUT /api/employees/schedules/:id/check-out - Marcar salida
router.put('/schedules/:id/check-out', authMiddleware, (req, res) => {
  try {
    const now = new Date().toTimeString().split(' ')[0];
    
    db.prepare(`
      UPDATE employee_schedules SET
        actual_end = ?,
        status = 'completed'
      WHERE id = ?
    `).run(now, req.params.id);
    
    const schedule = db.prepare('SELECT * FROM employee_schedules WHERE id = ?').get(req.params.id);
    res.json({ success: true, schedule });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al registrar salida' });
  }
});

// ==================== COMISIONES ====================

// GET /api/employees/commissions - Listar comisiones
router.get('/commissions', authMiddleware, (req, res) => {
  try {
    const { employee_id, status, start_date, end_date } = req.query;
    
    let sql = `
      SELECT c.*, e.name as employee_name, e.code as employee_code, s.total as sale_total
      FROM commissions c
      JOIN employees e ON c.employee_id = e.id
      JOIN sales s ON c.sale_id = s.id
      WHERE 1=1
    `;
    const params = [];
    
    if (employee_id) {
      sql += ' AND c.employee_id = ?';
      params.push(employee_id);
    }
    
    if (status) {
      sql += ' AND c.status = ?';
      params.push(status);
    }
    
    if (start_date) {
      sql += ' AND DATE(c.created_at) >= ?';
      params.push(start_date);
    }
    
    if (end_date) {
      sql += ' AND DATE(c.created_at) <= ?';
      params.push(end_date);
    }
    
    sql += ' ORDER BY c.created_at DESC';
    
    const commissions = db.prepare(sql).all(...params);
    
    // Totales
    const totals = db.prepare(`
      SELECT 
        status,
        COUNT(*) as count,
        SUM(amount) as total
      FROM commissions
      WHERE 1=1 ${employee_id ? 'AND employee_id = ?' : ''}
      GROUP BY status
    `).all(employee_id ? [employee_id] : []);
    
    res.json({ success: true, commissions, totals });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al listar comisiones' });
  }
});

// POST /api/employees/commissions/approve - Aprobar comisiones
router.post('/commissions/approve', authMiddleware, requireRole('admin', 'gerente'), (req, res) => {
  try {
    const { commission_ids } = req.body;
    
    db.prepare(`
      UPDATE commissions SET status = 'approved' WHERE id IN (${commission_ids.map(() => '?').join(',')}) AND status = 'pending'
    `).run(...commission_ids);
    
    res.json({ success: true, message: 'Comisiones aprobadas' });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al aprobar comisiones' });
  }
});

// POST /api/employees/commissions/pay - Pagar comisiones
router.post('/commissions/pay', authMiddleware, requireRole('admin'), (req, res) => {
  try {
    const { commission_ids } = req.body;
    
    db.prepare(`
      UPDATE commissions SET status = 'paid', paid_at = datetime('now') 
      WHERE id IN (${commission_ids.map(() => '?').join(',')}) AND status = 'approved'
    `).run(...commission_ids);
    
    res.json({ success: true, message: 'Comisiones pagadas' });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al pagar comisiones' });
  }
});

// ==================== NÓMINA ====================

// GET /api/employees/payroll - Historial de nómina
router.get('/payroll', authMiddleware, requireRole('admin', 'gerente'), (req, res) => {
  try {
    const { employee_id, status, limit = 50 } = req.query;
    
    let sql = `
      SELECT p.*, e.name as employee_name, e.code as employee_code
      FROM payroll p
      JOIN employees e ON p.employee_id = e.id
      WHERE 1=1
    `;
    const params = [];
    
    if (employee_id) {
      sql += ' AND p.employee_id = ?';
      params.push(employee_id);
    }
    
    if (status) {
      sql += ' AND p.status = ?';
      params.push(status);
    }
    
    sql += ' ORDER BY p.period_end DESC LIMIT ?';
    params.push(parseInt(limit));
    
    const payrolls = db.prepare(sql).all(...params);
    res.json({ success: true, payrolls });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al obtener nómina' });
  }
});

// POST /api/employees/payroll/generate - Generar nómina
router.post('/payroll/generate', authMiddleware, requireRole('admin'), (req, res) => {
  try {
    const { period_start, period_end, employee_ids } = req.body;
    
    if (!period_start || !period_end) {
      return res.status(400).json({ error: true, message: 'Período requerido' });
    }
    
    const employees = employee_ids 
      ? db.prepare(`SELECT * FROM employees WHERE id IN (${employee_ids.map(() => '?').join(',')}) AND active = 1`).all(...employee_ids)
      : db.prepare('SELECT * FROM employees WHERE active = 1').all();
    
    const results = [];
    
    for (const emp of employees) {
      // Calcular comisiones del período
      const commissions = db.prepare(`
        SELECT COALESCE(SUM(amount), 0) as total
        FROM commissions
        WHERE employee_id = ? AND status IN ('pending', 'approved') AND DATE(created_at) BETWEEN ? AND ?
      `).get(emp.id, period_start, period_end);
      
      const id = uuidv4();
      const total = emp.salary + commissions.total;
      
      db.prepare(`
        INSERT INTO payroll (id, employee_id, period_start, period_end, base_salary, commissions, total, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'draft')
      `).run(id, emp.id, period_start, period_end, emp.salary, commissions.total, total);
      
      results.push({
        id,
        employee_name: emp.name,
        base_salary: emp.salary,
        commissions: commissions.total,
        total
      });
    }
    
    res.json({ success: true, payrolls: results });
  } catch (err) {
    console.error('Error generating payroll:', err);
    res.status(500).json({ error: true, message: 'Error al generar nómina' });
  }
});

// PUT /api/employees/payroll/:id/approve
router.put('/payroll/:id/approve', authMiddleware, requireRole('admin'), (req, res) => {
  try {
    db.prepare('UPDATE payroll SET status = "approved" WHERE id = ? AND status = "draft"')
      .run(req.params.id);
    
    res.json({ success: true, message: 'Nómina aprobada' });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al aprobar nómina' });
  }
});

// PUT /api/employees/payroll/:id/pay
router.put('/payroll/:id/pay', authMiddleware, requireRole('admin'), (req, res) => {
  try {
    const payroll = db.prepare('SELECT * FROM payroll WHERE id = ?').get(req.params.id);
    
    if (!payroll) {
      return res.status(404).json({ error: true, message: 'Nómina no encontrada' });
    }
    
    const pay = db.transaction(() => {
      // Marcar nómina como pagada
      db.prepare('UPDATE payroll SET status = "paid", paid_at = datetime("now") WHERE id = ?')
        .run(req.params.id);
      
      // Marcar comisiones incluidas como pagadas
      db.prepare(`
        UPDATE commissions SET status = 'paid', paid_at = datetime('now')
        WHERE employee_id = ? AND status IN ('pending', 'approved')
          AND DATE(created_at) BETWEEN ? AND ?
      `).run(payroll.employee_id, payroll.period_start, payroll.period_end);
    });
    
    pay();
    
    res.json({ success: true, message: 'Nómina pagada' });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al pagar nómina' });
  }
});

// GET /api/employees/dashboard - Dashboard RRHH
router.get('/dashboard', authMiddleware, (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    
    // Empleados activos
    const activeEmployees = db.prepare('SELECT COUNT(*) as count FROM employees WHERE active = 1').get();
    
    // Turnos de hoy
    const todaySchedules = db.prepare(`
      SELECT es.*, e.name as employee_name, s.name as shift_name, s.start_time, s.end_time
      FROM employee_schedules es
      JOIN employees e ON es.employee_id = e.id
      JOIN shifts s ON es.shift_id = s.id
      WHERE es.date = ?
      ORDER BY s.start_time
    `).all(today);
    
    // Comisiones pendientes
    const pendingCommissions = db.prepare(`
      SELECT COALESCE(SUM(amount), 0) as total, COUNT(*) as count
      FROM commissions WHERE status = 'pending'
    `).get();
    
    // Top vendedores del mes
    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];
    const topSellers = db.prepare(`
      SELECT e.name, e.code, COUNT(s.id) as sales_count, SUM(s.total) as total_sales
      FROM employees e
      JOIN sales s ON e.id = s.employee_id
      WHERE DATE(s.created_at) >= ? AND s.status = 'completed'
      GROUP BY e.id
      ORDER BY total_sales DESC
      LIMIT 5
    `).all(monthStart);
    
    res.json({
      success: true,
      dashboard: {
        active_employees: activeEmployees.count,
        today_schedules: todaySchedules,
        pending_commissions: pendingCommissions,
        top_sellers: topSellers
      }
    });
  } catch (err) {
    res.status(500).json({ error: true, message: 'Error al obtener dashboard' });
  }
});

export default router;
